# NorthwindChinese(北風資料庫中文版)

北風資料庫的產生相關指令碼  

* * *

步驟：

1.  在資料庫中，新增一個DB，名稱為NorthwindChinese
2.  執行NorthwindChinese.sql

執行後，檢查相關資料表與資料內容  
^_^
