﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace firstMVC.Models
{
    public class Friend
    {
        public string Name { get; set; }
        public string Country { get; set; }

    }
}