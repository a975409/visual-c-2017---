﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcBootstrap.Controllers
{
    public class GridSystemController : Controller
    {
        // GET: GridSystem
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GridBasic()
        {
            return View();
        }

        public ActionResult ColumnsExample()
        {
            return View();
        }

        public ActionResult GridExampleRazor()
        {
            return View();
        }

        public ActionResult ColumnsMixed()
        {
            return View();
        }

        public ActionResult ColumnOffset()
        {
            return View();
        }

        public ActionResult TextAlignment()
        {
            return View();
        }
    }
}