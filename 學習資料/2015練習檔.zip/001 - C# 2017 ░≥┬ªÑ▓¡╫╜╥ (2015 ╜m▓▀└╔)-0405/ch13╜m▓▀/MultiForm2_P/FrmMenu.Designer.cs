﻿namespace MultiForm2
{
    partial class FrmMenu
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnBuy = new System.Windows.Forms.Button();
            this.BtnEnd = new System.Windows.Forms.Button();
            this.BtnSale = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnBuy
            // 
            this.BtnBuy.Location = new System.Drawing.Point(19, 86);
            this.BtnBuy.Name = "BtnBuy";
            this.BtnBuy.Size = new System.Drawing.Size(75, 23);
            this.BtnBuy.TabIndex = 0;
            this.BtnBuy.Text = "進貨";
            this.BtnBuy.UseVisualStyleBackColor = true;
            this.BtnBuy.Click += new System.EventHandler(this.BtnBuy_Click);
            // 
            // BtnEnd
            // 
            this.BtnEnd.Location = new System.Drawing.Point(189, 86);
            this.BtnEnd.Name = "BtnEnd";
            this.BtnEnd.Size = new System.Drawing.Size(75, 23);
            this.BtnEnd.TabIndex = 1;
            this.BtnEnd.Text = "結束";
            this.BtnEnd.UseVisualStyleBackColor = true;
            this.BtnEnd.Click += new System.EventHandler(this.BtnEnd_Click);
            // 
            // BtnSale
            // 
            this.BtnSale.Location = new System.Drawing.Point(104, 86);
            this.BtnSale.Name = "BtnSale";
            this.BtnSale.Size = new System.Drawing.Size(75, 23);
            this.BtnSale.TabIndex = 2;
            this.BtnSale.Text = "銷貨";
            this.BtnSale.UseVisualStyleBackColor = true;
            this.BtnSale.Click += new System.EventHandler(this.BtnSale_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 125);
            this.Controls.Add(this.BtnSale);
            this.Controls.Add(this.BtnEnd);
            this.Controls.Add(this.BtnBuy);
            this.Name = "FrmMenu";
            this.Text = "進銷存作業";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnBuy;
        private System.Windows.Forms.Button BtnEnd;
        private System.Windows.Forms.Button BtnSale;
    }
}

