﻿namespace MultiForm2
{
    partial class FrmSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSale = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnSale
            // 
            this.BtnSale.Location = new System.Drawing.Point(74, 92);
            this.BtnSale.Name = "BtnSale";
            this.BtnSale.Size = new System.Drawing.Size(75, 23);
            this.BtnSale.TabIndex = 0;
            this.BtnSale.Text = "離開";
            this.BtnSale.UseVisualStyleBackColor = true;
            this.BtnSale.Click += new System.EventHandler(this.BtnSale_Click);
            // 
            // FrmSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(230, 139);
            this.Controls.Add(this.BtnSale);
            this.Name = "FrmSale";
            this.Text = "銷貨處理";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnSale;
    }
}