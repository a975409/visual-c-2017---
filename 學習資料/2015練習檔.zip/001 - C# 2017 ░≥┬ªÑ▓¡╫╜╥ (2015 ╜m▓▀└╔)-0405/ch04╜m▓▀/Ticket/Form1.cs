﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            int height;  // 宣告height變數用來存放輸入的身高值
            try
            {
                // 使用 try...catch監控可能會發生執行時期例外的程式碼
                height = Convert.ToInt32(TxtHeight.Text);
            }
            catch
            {
                LblMsg.Text = "請輸入數字";
                return;
            }
            if (height >= 150)  // 若輸入數值大於等於150
                LblMsg.Text = "需購買成人票！";
            else if (height < 115)  // 若輸入數值小於115
                LblMsg.Text = "不需購票！";
            else  // 其餘情況
                LblMsg.Text = "需購買孩童票！";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LblMsg.Text = "請輸入身高後按查詢鈕！";
        }
    }
}
