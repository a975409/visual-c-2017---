﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Off_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            try
            {
                int buy = Convert.ToInt32(TxtBuy.Text);//取得消費金額
                int pay;   //實付金額
                if (buy > 1000)    //若消費金額>千元
                {
                    pay = Convert.ToInt32(buy * 0.9);  //打九折
                }
                else    //其餘
                {
                    pay = Convert.ToInt32(buy * 0.95);  //打九五折
                }
                LblPay.Text = "實付金額：" + pay.ToString("C0") + "元";
            }
            catch
            {
                MessageBox.Show("請輸入數值", "注意");  //顯示錯誤訊息
                TxtBuy.Clear();  //清除TxtBuy內之文字
                TxtBuy.Focus();  //設停駐焦點於TxtBuy之上
            }
        }
    }
}
