﻿namespace Switch01_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnEnd = new System.Windows.Forms.Button();
            this.LblGrade = new System.Windows.Forms.Label();
            this.LblMsg = new System.Windows.Forms.Label();
            this.BtnOK = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.LblTaxPay = new System.Windows.Forms.Label();
            this.LblDiscount = new System.Windows.Forms.Label();
            this.LblTaxRate = new System.Windows.Forms.Label();
            this.TxtNetIncome = new System.Windows.Forms.TextBox();
            this.LblIncome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnEnd
            // 
            this.BtnEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEnd.Location = new System.Drawing.Point(338, 131);
            this.BtnEnd.Margin = new System.Windows.Forms.Padding(2);
            this.BtnEnd.Name = "BtnEnd";
            this.BtnEnd.Size = new System.Drawing.Size(74, 28);
            this.BtnEnd.TabIndex = 29;
            this.BtnEnd.Text = "結束";
            this.BtnEnd.UseVisualStyleBackColor = true;
            this.BtnEnd.Click += new System.EventHandler(this.BtnEnd_Click);
            // 
            // LblGrade
            // 
            this.LblGrade.AutoSize = true;
            this.LblGrade.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGrade.Location = new System.Drawing.Point(14, 105);
            this.LblGrade.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblGrade.Name = "LblGrade";
            this.LblGrade.Size = new System.Drawing.Size(129, 21);
            this.LblGrade.TabIndex = 28;
            this.LblGrade.Text = "2. 級       距： ";
            // 
            // LblMsg
            // 
            this.LblMsg.AutoSize = true;
            this.LblMsg.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMsg.Location = new System.Drawing.Point(14, 245);
            this.LblMsg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(64, 16);
            this.LblMsg.TabIndex = 27;
            this.LblMsg.Text = "提示訊息";
            // 
            // BtnOK
            // 
            this.BtnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOK.Location = new System.Drawing.Point(338, 76);
            this.BtnOK.Margin = new System.Windows.Forms.Padding(2);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(74, 32);
            this.BtnOK.TabIndex = 26;
            this.BtnOK.Text = "試算";
            this.BtnOK.UseVisualStyleBackColor = true;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(53, 14);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(323, 37);
            this.label5.TabIndex = 25;
            this.label5.Text = "**** 所得稅試算表 ****";
            // 
            // LblTaxPay
            // 
            this.LblTaxPay.AutoSize = true;
            this.LblTaxPay.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTaxPay.Location = new System.Drawing.Point(14, 211);
            this.LblTaxPay.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblTaxPay.Name = "LblTaxPay";
            this.LblTaxPay.Size = new System.Drawing.Size(123, 21);
            this.LblTaxPay.TabIndex = 24;
            this.LblTaxPay.Text = "5. 應繳稅額 : ";
            // 
            // LblDiscount
            // 
            this.LblDiscount.AutoSize = true;
            this.LblDiscount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDiscount.Location = new System.Drawing.Point(14, 174);
            this.LblDiscount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblDiscount.Name = "LblDiscount";
            this.LblDiscount.Size = new System.Drawing.Size(123, 21);
            this.LblDiscount.TabIndex = 23;
            this.LblDiscount.Text = "4. 累進差額 : ";
            // 
            // LblTaxRate
            // 
            this.LblTaxRate.AutoSize = true;
            this.LblTaxRate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTaxRate.Location = new System.Drawing.Point(14, 139);
            this.LblTaxRate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblTaxRate.Name = "LblTaxRate";
            this.LblTaxRate.Size = new System.Drawing.Size(123, 21);
            this.LblTaxRate.TabIndex = 22;
            this.LblTaxRate.Text = "3. 所得稅率 : ";
            // 
            // TxtNetIncome
            // 
            this.TxtNetIncome.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNetIncome.Location = new System.Drawing.Point(163, 76);
            this.TxtNetIncome.Margin = new System.Windows.Forms.Padding(2);
            this.TxtNetIncome.Name = "TxtNetIncome";
            this.TxtNetIncome.Size = new System.Drawing.Size(157, 29);
            this.TxtNetIncome.TabIndex = 21;
            this.TxtNetIncome.Text = "請輸入 ...";
            // 
            // LblIncome
            // 
            this.LblIncome.AutoSize = true;
            this.LblIncome.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblIncome.Location = new System.Drawing.Point(14, 76);
            this.LblIncome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblIncome.Name = "LblIncome";
            this.LblIncome.Size = new System.Drawing.Size(158, 21);
            this.LblIncome.TabIndex = 20;
            this.LblIncome.Text = "1. 全年所得淨額 :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 321);
            this.Controls.Add(this.BtnEnd);
            this.Controls.Add(this.LblGrade);
            this.Controls.Add(this.LblMsg);
            this.Controls.Add(this.BtnOK);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LblTaxPay);
            this.Controls.Add(this.LblDiscount);
            this.Controls.Add(this.LblTaxRate);
            this.Controls.Add(this.TxtNetIncome);
            this.Controls.Add(this.LblIncome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnEnd;
        private System.Windows.Forms.Label LblGrade;
        private System.Windows.Forms.Label LblMsg;
        private System.Windows.Forms.Button BtnOK;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LblTaxPay;
        private System.Windows.Forms.Label LblDiscount;
        private System.Windows.Forms.Label LblTaxRate;
        private System.Windows.Forms.TextBox TxtNetIncome;
        private System.Windows.Forms.Label LblIncome;
    }
}

