﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Switch01_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LblIncome.Text = "1. 全年淨所得 : ";
            LblGrade.Text = "2. 級       距：";
            LblTaxRate.Text = "3. 所得稅率 : ";
            LblDiscount.Text = "4. 累進差額 : ";
            LblTaxPay.Text = "5. 應繳稅額 : ";
            TxtNetIncome.Text = "請輸入 ...";
            LblMsg.Text = "提示訊息";
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            int grade = 0;　　// 所得稅率級距 (1-6)
            double tax = 0;      // 所得稅金額
            double taxRate = 0, discount = 0;    // 所得稅率
            double netIncome = double.Parse(TxtNetIncome.Text);    // 所得淨額
            if (netIncome > 0)
            {
                grade = (netIncome <= 520000 ? 1 : (netIncome <= 1170000 ? 2 : (netIncome <= 2350000
                              ? 3 : (netIncome <= 4400000 ? 4 : (netIncome <= 10000000 ? 5 : 6)))));
                taxRate = (grade == 1 ? 5 : (grade == 2 ? 12 : (grade == 3 ? 20 : (grade == 4 ? 30 :
                    (grade == 5 ? 40 : 45)))));  //判斷稅率
                discount = (grade == 1 ? 0 : (grade == 2 ? 36400 : (grade == 3 ? 130000 :
                    (grade == 4 ? 365000 : (grade == 5 ? 805000 : 1305000)))));  //判斷累進差額
                tax = netIncome * taxRate / 100 - discount;  //計算應納稅額
                LblGrade.Text = "2. 級       距：" + grade;
                LblTaxRate.Text = "3. 所得稅率 : " + taxRate.ToString() + "%";
                LblDiscount.Text = "4. 累進差額 : " + discount.ToString() + "元";
                LblTaxPay.Text = "5. 應繳稅額 : " + tax.ToString() + "元";
                LblMsg.Text = "  應納稅額 ＝ 綜合所得淨額 × 稅率 － 累進差額  ";
            }
            else
            {
                LblMsg.Text = "  ****  不用扣稅  **** ";
                taxRate = 0;
                discount = 0;
            }
        }

        private void BtnEnd_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
