﻿namespace ETC
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RdbMode2 = new System.Windows.Forms.RadioButton();
            this.RdbMode1 = new System.Windows.Forms.RadioButton();
            this.BtnOK = new System.Windows.Forms.Button();
            this.LblPay = new System.Windows.Forms.Label();
            this.TxtKM = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ChkNight = new System.Windows.Forms.CheckBox();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RdbMode2);
            this.groupBox2.Controls.Add(this.RdbMode1);
            this.groupBox2.Location = new System.Drawing.Point(21, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(244, 61);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "收費別";
            // 
            // RdbMode2
            // 
            this.RdbMode2.AutoSize = true;
            this.RdbMode2.Location = new System.Drawing.Point(123, 21);
            this.RdbMode2.Name = "RdbMode2";
            this.RdbMode2.Size = new System.Drawing.Size(71, 16);
            this.RdbMode2.TabIndex = 1;
            this.RdbMode2.TabStop = true;
            this.RdbMode2.Text = "連續假日";
            this.RdbMode2.UseVisualStyleBackColor = true;
            // 
            // RdbMode1
            // 
            this.RdbMode1.AutoSize = true;
            this.RdbMode1.Location = new System.Drawing.Point(11, 26);
            this.RdbMode1.Name = "RdbMode1";
            this.RdbMode1.Size = new System.Drawing.Size(47, 16);
            this.RdbMode1.TabIndex = 0;
            this.RdbMode1.TabStop = true;
            this.RdbMode1.Text = "平日";
            this.RdbMode1.UseVisualStyleBackColor = true;
            // 
            // BtnOK
            // 
            this.BtnOK.Location = new System.Drawing.Point(202, 10);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(63, 23);
            this.BtnOK.TabIndex = 10;
            this.BtnOK.Text = "確定";
            this.BtnOK.UseVisualStyleBackColor = true;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // LblPay
            // 
            this.LblPay.AutoSize = true;
            this.LblPay.Location = new System.Drawing.Point(149, 117);
            this.LblPay.Name = "LblPay";
            this.LblPay.Size = new System.Drawing.Size(65, 12);
            this.LblPay.TabIndex = 9;
            this.LblPay.Text = "應繳通行費";
            // 
            // TxtKM
            // 
            this.TxtKM.Location = new System.Drawing.Point(119, 10);
            this.TxtKM.Name = "TxtKM";
            this.TxtKM.Size = new System.Drawing.Size(63, 22);
            this.TxtKM.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "請輸入公里數:";
            // 
            // ChkNight
            // 
            this.ChkNight.AutoSize = true;
            this.ChkNight.Location = new System.Drawing.Point(19, 117);
            this.ChkNight.Name = "ChkNight";
            this.ChkNight.Size = new System.Drawing.Size(120, 16);
            this.ChkNight.TabIndex = 12;
            this.ChkNight.Text = "連續假日夜間免費";
            this.ChkNight.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 149);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.BtnOK);
            this.Controls.Add(this.LblPay);
            this.Controls.Add(this.TxtKM);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ChkNight);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton RdbMode2;
        private System.Windows.Forms.RadioButton RdbMode1;
        private System.Windows.Forms.Button BtnOK;
        private System.Windows.Forms.Label LblPay;
        private System.Windows.Forms.TextBox TxtKM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox ChkNight;
    }
}

