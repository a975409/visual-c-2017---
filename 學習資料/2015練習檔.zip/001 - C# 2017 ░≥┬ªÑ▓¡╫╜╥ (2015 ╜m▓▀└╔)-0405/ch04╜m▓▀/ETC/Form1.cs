﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ETC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtKM.Text = "50";
            RdbMode1.Checked = true;
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            int km;
            try
            {
                km = Convert.ToInt32(TxtKM.Text);
            }
            catch
            {
                MessageBox.Show("公里數請輸入數值！", "注意");
                return;
            }
            double pay = 0.0;  //預設應繳金額為0
            if (RdbMode1.Checked == true)
            {
                if (km > 20)
                {
                    if (km > 200)
                        pay = (km - 200) * 0.9 + (200 - 20) * 1.2;
                    else
                        pay = (km - 20) * 1.2;
                }
            }
            else
            {
                if (ChkNight.Checked == false)
                {
                    pay = km * 1.2;
                }
            }
            LblPay.Text = "應繳通行費：" + pay.ToString("g") + " 元";
        }
    }
}
