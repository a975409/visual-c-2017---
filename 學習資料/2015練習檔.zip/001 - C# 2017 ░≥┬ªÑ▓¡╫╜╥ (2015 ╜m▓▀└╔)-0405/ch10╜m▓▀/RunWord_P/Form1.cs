﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RunWord
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool move_d = true;   //記錄跑馬燈文字移動方向

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 100;
            toolStripTextBox1.Text = "經驗是良師";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (move_d == true)      //true 由左向右移
            {
                LblMsg.Left += 10;
                if (LblMsg.Left >= this.Width) LblMsg.Left = -LblMsg.Width;
            }
            else                     //false 由左向右移
            {
                LblMsg.Left -= 10;
                if (LblMsg.Left <= -LblMsg.Width) LblMsg.Left = this.Width;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            move_d = false;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            move_d = true;
        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            LblMsg.Text = toolStripTextBox1.Text;
        }

        private void 紅色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LblMsg.ForeColor = Color.Red;
        }

        private void 綠色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LblMsg.ForeColor = Color.Green;
        }

        private void 藍色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LblMsg.ForeColor = Color.Blue;
        }
    }
}
