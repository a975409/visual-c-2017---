﻿namespace Runner_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ImgRun = new System.Windows.Forms.ImageList(this.components);
            this.TmrRun = new System.Windows.Forms.Timer(this.components);
            this.TmrMove = new System.Windows.Forms.Timer(this.components);
            this.ImgBtn = new System.Windows.Forms.ImageList(this.components);
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnStart = new System.Windows.Forms.Button();
            this.PicRun = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicRun)).BeginInit();
            this.SuspendLayout();
            // 
            // ImgRun
            // 
            this.ImgRun.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImgRun.ImageStream")));
            this.ImgRun.TransparentColor = System.Drawing.Color.Transparent;
            this.ImgRun.Images.SetKeyName(0, "man1.gif");
            this.ImgRun.Images.SetKeyName(1, "man2.gif");
            this.ImgRun.Images.SetKeyName(2, "man3.gif");
            this.ImgRun.Images.SetKeyName(3, "man4.gif");
            // 
            // TmrRun
            // 
            this.TmrRun.Tick += new System.EventHandler(this.TmrRun_Tick);
            // 
            // TmrMove
            // 
            this.TmrMove.Tick += new System.EventHandler(this.TmrMove_Tick);
            // 
            // ImgBtn
            // 
            this.ImgBtn.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImgBtn.ImageStream")));
            this.ImgBtn.TransparentColor = System.Drawing.Color.Transparent;
            this.ImgBtn.Images.SetKeyName(0, "start.bmp");
            this.ImgBtn.Images.SetKeyName(1, "stop.bmp");
            // 
            // BtnStop
            // 
            this.BtnStop.ImageIndex = 1;
            this.BtnStop.ImageList = this.ImgBtn;
            this.BtnStop.Location = new System.Drawing.Point(241, 84);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(30, 30);
            this.BtnStop.TabIndex = 4;
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnStart
            // 
            this.BtnStart.ImageIndex = 0;
            this.BtnStart.ImageList = this.ImgBtn;
            this.BtnStart.Location = new System.Drawing.Point(205, 84);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(30, 30);
            this.BtnStart.TabIndex = 3;
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // PicRun
            // 
            this.PicRun.Location = new System.Drawing.Point(227, 30);
            this.PicRun.Name = "PicRun";
            this.PicRun.Size = new System.Drawing.Size(45, 45);
            this.PicRun.TabIndex = 2;
            this.PicRun.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 121);
            this.Controls.Add(this.BtnStop);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.PicRun);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicRun)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList ImgRun;
        private System.Windows.Forms.Timer TmrRun;
        private System.Windows.Forms.Timer TmrMove;
        private System.Windows.Forms.ImageList ImgBtn;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.PictureBox PicRun;
    }
}

