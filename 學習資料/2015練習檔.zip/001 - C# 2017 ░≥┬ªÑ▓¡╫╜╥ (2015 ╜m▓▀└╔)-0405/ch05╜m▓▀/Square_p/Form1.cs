﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Square_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string i;           // 記錄使用者輸入的資料
            double num = 0;     // 使用者輸入資料轉成double的值
            bool pass = true;   // 紀錄是否為數值
            DialogResult dr;    // 宣告DialogResult型別變數 dr
            do          // do...while外迴圈
            {
                do      // do...while內迴圈
                {
                    pass = true;    //預設為數值檢查通過
                    i = Microsoft.VisualBasic.Interaction.InputBox("請輸入數值：", "求平方");
                    try     //使用try來捕捉例外錯誤
                    {
                        num = Convert.ToDouble(i);  // 將使用者輸入的資料轉成double
                    }
                    catch   //錯誤發生時
                    {
                        MessageBox.Show("請輸入數值！", "錯誤");
                        pass = false;   //設為數值檢查不通過
                    }
                } while (pass == false);  // 若pass等於false(即不是數值)就繼續迴圈
                dr = MessageBox.Show(i + "的平方等於" + (num * num).ToString() + "\n是否繼續?", "平方", MessageBoxButtons.YesNo);
            } while (dr == DialogResult.Yes);   //若傳回值為Yes就繼續迴圈
            Application.Exit();		//結束程式
        }
    }
}
