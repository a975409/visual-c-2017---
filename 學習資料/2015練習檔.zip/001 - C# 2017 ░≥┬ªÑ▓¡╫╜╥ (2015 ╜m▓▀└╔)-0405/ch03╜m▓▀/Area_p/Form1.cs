﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Area_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string uName = Microsoft.VisualBasic.Interaction.
                InputBox("請輸入姓名：", "輸入");
            DialogResult dr = MessageBox.Show(uName + "歡迎您！", "歡迎",
                MessageBoxButtons.OK, MessageBoxIcon.Asterisk);  //有傳回值寫法
            Text = uName;  //表單標題顯示姓名
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            try
            {
                double w, h;
                w = Convert.ToDouble(TxtW.Text);
                h = Convert.ToDouble(TxtH.Text);
                LblArea.Text = "面積等於：" + Convert.ToString(w * h * 0.3025) + " 坪";
            }
            catch
            {
                MessageBox.Show("請輸入長和寛度！", "注意！",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("感謝使用程式！", "謝謝", MessageBoxButtons.OK);
            Application.Exit();
        }
    }
}
