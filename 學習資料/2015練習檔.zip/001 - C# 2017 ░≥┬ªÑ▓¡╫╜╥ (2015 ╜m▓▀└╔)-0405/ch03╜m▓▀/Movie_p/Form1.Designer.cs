﻿namespace Movie_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LblPriceF = new System.Windows.Forms.Label();
            this.LblPriceH = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.LblSumF = new System.Windows.Forms.Label();
            this.LblSumH = new System.Windows.Forms.Label();
            this.LblTotal = new System.Windows.Forms.Label();
            this.TxtQtyF = new System.Windows.Forms.TextBox();
            this.TxtQtyH = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "全票";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "優待票";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "單價";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(126, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "張數";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(192, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "金額";
            // 
            // LblPriceF
            // 
            this.LblPriceF.AutoSize = true;
            this.LblPriceF.Location = new System.Drawing.Point(65, 40);
            this.LblPriceF.Name = "LblPriceF";
            this.LblPriceF.Size = new System.Drawing.Size(23, 12);
            this.LblPriceF.TabIndex = 5;
            this.LblPriceF.Text = "250";
            // 
            // LblPriceH
            // 
            this.LblPriceH.AutoSize = true;
            this.LblPriceH.Location = new System.Drawing.Point(65, 76);
            this.LblPriceH.Name = "LblPriceH";
            this.LblPriceH.Size = new System.Drawing.Size(23, 12);
            this.LblPriceH.TabIndex = 6;
            this.LblPriceH.Text = "200";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(126, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "合計";
            // 
            // LblSumF
            // 
            this.LblSumF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblSumF.Location = new System.Drawing.Point(173, 35);
            this.LblSumF.Name = "LblSumF";
            this.LblSumF.Size = new System.Drawing.Size(48, 23);
            this.LblSumF.TabIndex = 8;
            this.LblSumF.Text = "label9";
            // 
            // LblSumH
            // 
            this.LblSumH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblSumH.Location = new System.Drawing.Point(173, 71);
            this.LblSumH.Name = "LblSumH";
            this.LblSumH.Size = new System.Drawing.Size(48, 23);
            this.LblSumH.TabIndex = 9;
            this.LblSumH.Text = "label10";
            // 
            // LblTotal
            // 
            this.LblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblTotal.Location = new System.Drawing.Point(173, 102);
            this.LblTotal.Name = "LblTotal";
            this.LblTotal.Size = new System.Drawing.Size(48, 23);
            this.LblTotal.TabIndex = 10;
            this.LblTotal.Text = "label11";
            // 
            // TxtQtyF
            // 
            this.TxtQtyF.Location = new System.Drawing.Point(107, 35);
            this.TxtQtyF.Name = "TxtQtyF";
            this.TxtQtyF.Size = new System.Drawing.Size(48, 22);
            this.TxtQtyF.TabIndex = 11;
            this.TxtQtyF.TextChanged += new System.EventHandler(this.TxtQtyF_TextChanged);
            this.TxtQtyF.Enter += new System.EventHandler(this.TxtQtyF_Enter);
            // 
            // TxtQtyH
            // 
            this.TxtQtyH.Location = new System.Drawing.Point(107, 71);
            this.TxtQtyH.Name = "TxtQtyH";
            this.TxtQtyH.Size = new System.Drawing.Size(48, 22);
            this.TxtQtyH.TabIndex = 12;
            this.TxtQtyH.TextChanged += new System.EventHandler(this.TxtQtyH_TextChanged);
            this.TxtQtyH.Enter += new System.EventHandler(this.TxtQtyH_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(239, 143);
            this.Controls.Add(this.TxtQtyH);
            this.Controls.Add(this.TxtQtyF);
            this.Controls.Add(this.LblTotal);
            this.Controls.Add(this.LblSumH);
            this.Controls.Add(this.LblSumF);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.LblPriceH);
            this.Controls.Add(this.LblPriceF);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LblPriceF;
        private System.Windows.Forms.Label LblPriceH;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LblSumF;
        private System.Windows.Forms.Label LblSumH;
        private System.Windows.Forms.Label LblTotal;
        private System.Windows.Forms.TextBox TxtQtyF;
        private System.Windows.Forms.TextBox TxtQtyH;
    }
}

