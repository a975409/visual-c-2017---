﻿namespace PcDiy_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnNew = new System.Windows.Forms.Button();
            this.BtnOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CblDevice = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LblSum = new System.Windows.Forms.Label();
            this.CbxCRT = new System.Windows.Forms.ComboBox();
            this.LstBuy = new System.Windows.Forms.ListBox();
            this.LstPC = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnNew
            // 
            this.BtnNew.Location = new System.Drawing.Point(83, 123);
            this.BtnNew.Name = "BtnNew";
            this.BtnNew.Size = new System.Drawing.Size(50, 23);
            this.BtnNew.TabIndex = 40;
            this.BtnNew.Text = "重新";
            this.BtnNew.UseVisualStyleBackColor = true;
            this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
            // 
            // BtnOK
            // 
            this.BtnOK.Location = new System.Drawing.Point(14, 123);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(50, 23);
            this.BtnOK.TabIndex = 41;
            this.BtnOK.Text = "確定";
            this.BtnOK.UseVisualStyleBackColor = true;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(288, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 39;
            this.label1.Text = "購物籃";
            // 
            // CblDevice
            // 
            this.CblDevice.FormattingEnabled = true;
            this.CblDevice.Location = new System.Drawing.Point(146, 68);
            this.CblDevice.Name = "CblDevice";
            this.CblDevice.Size = new System.Drawing.Size(121, 72);
            this.CblDevice.TabIndex = 38;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(144, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 37;
            this.label4.Text = "週邊配備";
            // 
            // LblSum
            // 
            this.LblSum.AutoSize = true;
            this.LblSum.Location = new System.Drawing.Point(280, 134);
            this.LblSum.Name = "LblSum";
            this.LblSum.Size = new System.Drawing.Size(41, 12);
            this.LblSum.TabIndex = 36;
            this.LblSum.Text = "合計：";
            // 
            // CbxCRT
            // 
            this.CbxCRT.FormattingEnabled = true;
            this.CbxCRT.Location = new System.Drawing.Point(146, 30);
            this.CbxCRT.Name = "CbxCRT";
            this.CbxCRT.Size = new System.Drawing.Size(121, 20);
            this.CbxCRT.TabIndex = 35;
            // 
            // LstBuy
            // 
            this.LstBuy.FormattingEnabled = true;
            this.LstBuy.ItemHeight = 12;
            this.LstBuy.Location = new System.Drawing.Point(282, 30);
            this.LstBuy.Name = "LstBuy";
            this.LstBuy.Size = new System.Drawing.Size(132, 100);
            this.LstBuy.TabIndex = 33;
            // 
            // LstPC
            // 
            this.LstPC.FormattingEnabled = true;
            this.LstPC.ItemHeight = 12;
            this.LstPC.Location = new System.Drawing.Point(13, 30);
            this.LstPC.Name = "LstPC";
            this.LstPC.Size = new System.Drawing.Size(120, 76);
            this.LstPC.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(144, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 32;
            this.label3.Text = "液晶螢幕尺寸";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 31;
            this.label2.Text = "主機廠牌";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 161);
            this.Controls.Add(this.BtnNew);
            this.Controls.Add(this.BtnOK);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CblDevice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LblSum);
            this.Controls.Add(this.CbxCRT);
            this.Controls.Add(this.LstBuy);
            this.Controls.Add(this.LstPC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnNew;
        private System.Windows.Forms.Button BtnOK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox CblDevice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label LblSum;
        private System.Windows.Forms.ComboBox CbxCRT;
        private System.Windows.Forms.ListBox LstBuy;
        private System.Windows.Forms.ListBox LstPC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

