﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PcDiy_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] Pc = new string[] { "華爍主機", "碁峰主機", "技佳主機", "津英主機" };
        int[] PcPrice = new int[] { 20000, 18000, 15000, 12000 };
        string[] Crt = new string[] { "15吋", "17吋", "19吋" };
        int[] CrtPrice = new int[] { 4000, 5000, 6000 };
        string[] device = new string[] { "滑鼠", "鍵盤", "8G隨身碟", "DVD燒錄器" };
        int[] devicePrice = new int[] { 300, 400, 500, 800 };
        int deviceSum = 0;   // 存放勾選配件的合計金額，讓所有事件處理函式共用
        private void Form1_Load(object sender, EventArgs e)
        {   // 設定主機清單初值
            for (int i = 0; i <= Pc.GetUpperBound(0); i++)
            {
                LstPC.Items.Add(Pc[i] + "(" + Convert.ToString(PcPrice[i]) + ")");
            }
            for (int i = 0; i <= Crt.GetUpperBound(0); i++)// 設定螢幕下拉式清單初值
            {
                CbxCRT.Items.Add(Crt[i] + "(" + Convert.ToString(CrtPrice[i]) + ")");
            }
            for (int i = 0; i <= device.GetUpperBound(0); i++)// 設定 週邊配件核取清單初值
            {
                CblDevice.Items.Add(device[i] + "(" + Convert.ToString(devicePrice[i]) + ")");
            }
            // 設定各清單最開頭項目為預選項目
            CbxCRT.SelectedIndex = 0;
            LstPC.SelectedIndex = 0;
            CblDevice.CheckOnClick = true;// 將核取清單按一次即選取
        }
        //按 確定 鈕時
        private void BtnOK_Click(object sender, EventArgs e)
        {
            LstBuy.Items.Add(LstPC.Text);
            LstBuy.Items.Add(CbxCRT.Text);
            deviceSum = 0;    // 存放被勾選項目的總金額預設為0                
            for (int i = 0; i < 4; i++)  // 將有被勾選項的單價加總至devicSum變數
            {
                if (CblDevice.GetItemChecked(i) == true)
                {
                    deviceSum += devicePrice[i];
                    LstBuy.Items.Add(CblDevice.Items[i]);
                }
            }
            // 主機單價+螢幕單價+配件總和
            int sum = PcPrice[LstPC.SelectedIndex] + CrtPrice[CbxCRT.SelectedIndex] + deviceSum;
            LblSum.Text = "合計：" + Convert.ToString(sum) + " 元";
            BtnOK.Enabled = false;  //確定鈕不能使用
        }
        //按 重新 鈕時
        private void BtnNew_Click(object sender, EventArgs e)
        {
            // 設定各清單最開頭項目為預選項目
            CbxCRT.SelectedIndex = 0;
            LstPC.SelectedIndex = 0;
            LstBuy.Items.Clear();   //清空購物籃中的所有項目
            for (int i = 0; i < 4; i++)  // 將配件的所有項目設為未勾選
            {
                CblDevice.SetItemChecked(i, false);
            }
            BtnOK.Enabled = true;  //確定鈕可以使用
        }
    }
}
