﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Singer_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] singer = new string[] { "曾沛慈", "田馥甄", "A-Lin", "楊丞琳", "蔡依林", "彭佳慧" };
        string[] msg = new string[] { "我是曾沛慈...福茂", "日常...華研",
            "罪惡感...索尼", "年輪說...環球", "Play 我呸...華納", "大齡女子...金牌大風" };
        int[] votes = new int[6];   //紀錄票數
        //設定初值
        private void Form1_Load(object sender, EventArgs e)
        {   //將singer陣列加入CboSinger項目
            CboSinger.Items.AddRange(singer);
            for (int i = 0; i < singer.Length; i++) //逐一加入項目到LstVote
            {   //項目為歌手加上票數
                LstVote.Items.Add(singer[i] + "\t" + votes[i] + "票");
            }
            CboSinger.SelectedItem = singer[0];     //預設選取第一個歌手
        }
        //當CboSinger選取的註標值改變時
        private void CboSinger_SelectedIndexChanged(object sender, EventArgs e)
        {   //根據選取的註標值，在LblMsg顯示對應的msg陣列元素
            LblMsg.Text = msg[CboSinger.SelectedIndex];
        }
        //當按 投票 鈕時
        private void BtnVote_Click(object sender, EventArgs e)
        {   //根據選取的註標值，對應的votes陣列元素值加1
            votes[CboSinger.SelectedIndex] += 1;
            string voteSinger = CboSinger.Text;     //紀錄使用者選取的項目文字(即歌手)
            int[] votes2 = new int[votes.Length];   //宣告votes2整數陣列，大小和votes陣列相同
            votes.CopyTo(votes2, 0);    //將votes陣列的內容複製到votes2陣列
            Array.Sort(votes, singer);  //votes陣列遞增排序，singer陣列同步調整
            Array.Sort(votes2, msg);    //votes2陣列遞增排序，msg陣列同步調整
            Array.Reverse(votes);       //反轉votes陣列
            Array.Reverse(singer);      //反轉singer陣列
            Array.Reverse(msg);         //反轉msg陣列
            LstVote.Items.Clear();                  //清空LstVote項目
            for (int i = 0; i < singer.Length; i++) //逐一加入項目到LstVote
            {
                LstVote.Items.Add(singer[i] + "\t" + votes[i] + "票");
            }
            CboSinger.Items.Clear();    //清空歌手下拉式清單
            CboSinger.Items.AddRange(singer);       //歌手陣列值加入歌手下拉式清單
            CboSinger.SelectedItem = voteSinger;    //選取使用者原選取的歌手
        }
    }
}
