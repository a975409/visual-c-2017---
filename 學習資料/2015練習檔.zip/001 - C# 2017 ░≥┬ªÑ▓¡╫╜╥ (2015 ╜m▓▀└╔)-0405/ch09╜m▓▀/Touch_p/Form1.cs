﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Touch_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool drag = false;  //記錄是否可拖曳，預設不可拖曳
        int sX, sY;             //記錄滑鼠按下時的座標值

        private void Form1_Load(object sender, EventArgs e)
        {
            MouseWheel += Lbl_Zoom;
        }

        private void Lbl_Zoom(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
            {
                if (LblTouch.Font.Size < 60)
                    LblTouch.Font = new Font(LblTouch.Font.FontFamily, LblTouch.Font.Size + 2);
            }
            else
            {
                if (LblTouch.Font.Size > 8)
                    LblTouch.Font = new Font(LblTouch.Font.FontFamily, LblTouch.Font.Size - 2);
            }
        }

        private void LblTouch_Click(object sender, EventArgs e)
        {
            LblTouch.Text = "點按";
        }

        private void LblTouch_DoubleClick(object sender, EventArgs e)
        {
            LblTouch.Text = "快按兩下";
        }

        private void LblTouch_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                LblTouch.Text = "長按";
            else
                LblTouch.Text = "點按";
        }

        private void LblTouch_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)  //若是按滑鼠左鍵
            {
                drag = true;        //設drag=true，表可拖曳
                sX = e.X; sY = e.Y; //記錄滑鼠的座標值
            }
        }

        private void LblTouch_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)      //若設drag=true
            {
                LblTouch.Left += e.X - sX;
                LblTouch.Top += e.Y - sY;
            }
        }

        private void LblTouch_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;   //設drag=false，表不可拖曳
        }
    }
}
