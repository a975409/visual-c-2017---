﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MouseDrag_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int downX, downY;   //紀錄按下滑鼠鍵時的游標座標
        bool drag = false;  //宣告drag 變數,用來記錄是否可拖曳
        // 在picBlack按下滑鼠鍵執行
        private void PicBlack_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // 判斷是否按下滑鼠左鍵
            {
                drag = true;    // 若drag為true，表示按下滑鼠左鍵，允許PicBlack可被拖曳
                downX = e.X;    //紀錄按下滑鼠鍵時的游標X座標
                downY = e.Y;    //紀錄按下滑鼠鍵時的游標Y座標
            }
        }
        // 當滑鼠在PicBlack內移動時執行
        private void PicBlack_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)  // 判斷是否己按下滑鼠左鍵
            {
                // 將目前滑鼠座標值減按下時的座標值當圖片方塊左上角座標
                PicBlack.Left += e.X - downX;
                PicBlack.Top += e.Y - downY;
            }
        }
        // 在PicBlack放開滑鼠鍵時執行
        private void PicBlack_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;  //不允許拖曳
        }
    }
}
