﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KeyDown_Up_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // 表單載入時執行
        private void Form1_Load(object sender, EventArgs e)
        {
            PicRider.Image = Image.FromFile("bike_go.gif");
        }
        // 在表單上按下鍵盤鍵時執行
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // 在lblKey上顯示鍵值
            LblKey.Text = "按下" + e.KeyCode.ToString() + "鍵, 鍵值為" + e.KeyValue.ToString();
            switch (e.KeyCode)
            {
                case Keys.Right:
                    PicRider.Image = Image.FromFile("bike_go.gif");
                    if (PicRider.Left >= ClientSize.Width)  // 判斷是否超出表單的右邊界
                    {
                        PicRider.Left = -PicRider.Width + 20;
                    }
                    else
                    {
                        PicRider.Left += 20;
                    }
                    LblState.Text = "前進!!";
                    break;
                case Keys.Left:
                    PicRider.Image = Image.FromFile("bike_go.gif");
                    if (PicRider.Width + PicRider.Left <= 0)  // 判斷是否超出表單的左邊界
                    {
                        PicRider.Left = ClientSize.Width - 20;
                    }
                    else
                    {
                        PicRider.Left -= 20;
                    }
                    LblState.Text = "後退!!";
                    break;
                case Keys.Up:
                    PicRider.Image = Image.FromFile("bike_up.gif");
                    if (PicRider.Left >= ClientSize.Width)  // 判斷是否超出表單的右邊界
                    {
                        PicRider.Left = -PicRider.Width + 5;
                    }
                    else
                    {
                        PicRider.Left += 5;
                    }
                    LblState.Text = "舉孤輪!!";
                    break;
                case Keys.Down:
                    PicRider.Image = Image.FromFile("bike_stop.gif");
                    LblState.Text = "煞車!!";
                    break;
            }
        }
        // 在表單上放開鍵盤鍵時執行
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            PicRider.Image = Image.FromFile("bike_go.gif");
            LblKey.Text = "鬆開鍵";
            LblState.Text = "停止!!";
        }
    }
}
