﻿namespace KeyDown_Up_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.PicRider = new System.Windows.Forms.PictureBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.LblState = new System.Windows.Forms.Label();
            this.LblKey = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PicRider)).BeginInit();
            this.SuspendLayout();
            // 
            // PicRider
            // 
            this.PicRider.Location = new System.Drawing.Point(11, 62);
            this.PicRider.Name = "PicRider";
            this.PicRider.Size = new System.Drawing.Size(103, 62);
            this.PicRider.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PicRider.TabIndex = 23;
            this.PicRider.TabStop = false;
            // 
            // Label1
            // 
            this.Label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Label1.Location = new System.Drawing.Point(-1, 125);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(349, 43);
            this.Label1.TabIndex = 26;
            // 
            // LblState
            // 
            this.LblState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LblState.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblState.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LblState.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LblState.Location = new System.Drawing.Point(25, 9);
            this.LblState.Name = "LblState";
            this.LblState.Size = new System.Drawing.Size(80, 23);
            this.LblState.TabIndex = 24;
            this.LblState.Text = "停止!!";
            // 
            // LblKey
            // 
            this.LblKey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LblKey.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblKey.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LblKey.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LblKey.Location = new System.Drawing.Point(128, 9);
            this.LblKey.Name = "LblKey";
            this.LblKey.Size = new System.Drawing.Size(192, 23);
            this.LblKey.TabIndex = 25;
            this.LblKey.Text = "未按鍵!!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 166);
            this.Controls.Add(this.PicRider);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.LblState);
            this.Controls.Add(this.LblKey);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.PicRider)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.PictureBox PicRider;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label LblState;
        internal System.Windows.Forms.Label LblKey;
    }
}

