﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum2_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // CountSum方法用來顯示n累加到m增值為s的結果
        private void CountSum(int n, int m, int s)
        {
            int total = 0;
            for (int i = n; i <= m; i += s)
            {
                total += i;
            }
            MessageBox.Show(n.ToString() + "加到" + m.ToString() + "增值為" + s.ToString() + "的總和為 ：" + total.ToString() + "\n\n");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CountSum(1, 10, 2);      //呼叫CountSum方法進行1累加到10增值為2
            CountSum(5, 12, 3);      //呼叫CountSum方法進行5累加到12增值為3
            Application.Exit();
        }
    }
}
