﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Swap_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Large方法
        private void Large(ref int n1, ref int n2)
        {
            if (n2 > n1)   //如果n2>n1，就將兩數交換
            {
                int temp = n1;
                n1 = n2;
                n2 = temp;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int a = 10, b = 15;
            MessageBox.Show("呼叫Large方法前: a = " + a.ToString() +
                             "  b = " + b.ToString());
            Large(ref a, ref b);   //呼叫Large方法
            MessageBox.Show("呼叫Large方法後: a = " + a.ToString() +
                             "  b = " + b.ToString());
            Application.Exit();
        }
    }
}
