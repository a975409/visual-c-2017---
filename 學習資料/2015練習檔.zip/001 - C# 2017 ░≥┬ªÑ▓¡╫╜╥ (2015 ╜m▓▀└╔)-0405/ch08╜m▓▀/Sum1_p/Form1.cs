﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum1_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // CountSum方法用來傳回n累加到m增值為s的結果
        private int CountSum(int n, int m, int s)
        {
            int total = 0;
            for (int i = n; i <= m; i += s)
            {
                total += i;
            }
            return total;     // 傳回total，並返回原呼叫處
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int tot = 0;
            tot = CountSum(1, 10, 2);      //呼叫CountSum方法進行1累加到10增值為2，傳回值指定給tot
            LblMsg.Text = "1加到10增值為2的總和為 ：" + Convert.ToString(tot) + "\n\n";
            //呼叫CountSum方法進行5累加到12增值為3，傳回值直接顯示不指定給變數
            LblMsg.Text += "5加到12增值為3的總和為 ：" + Convert.ToString(CountSum(5, 12, 3)) + "\n";
        }
    }
}
