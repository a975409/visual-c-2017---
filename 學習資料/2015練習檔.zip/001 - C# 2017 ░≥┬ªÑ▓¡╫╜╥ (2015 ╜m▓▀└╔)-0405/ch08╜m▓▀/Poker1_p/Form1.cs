﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poker1_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int pointPc, pointUser;  // 宣告point整數欄位變數來存放得到的點數
        Random rnd = new Random();
        // 表單載入時執行
        private void Form1_Load(object sender, EventArgs e)
        {
            TmrRun.Interval = 50;  // 指定每50毫秒(即0.05秒)執行一次TmrRun_Tick事件
        }
        // 按 [開始] 鈕執行
        private void BtnStart_Click(object sender, EventArgs e)
        {
            pointPc = rnd.Next(1, 14);//產生1~13變數
            PicPc.Image = ImgPoker.Images[pointPc - 1];
            TmrRun.Enabled = true;  //啟動TmrRun計時器
        }
        // 按 [停止] 鈕執行
        private void BtnStop_Click(object sender, EventArgs e)
        {
            TmrRun.Enabled = false; // 停止TmrRun計時器
            if (pointUser > pointPc)
            {
                LblMsg.Text = "恭喜你獲勝 !!";
            }
            else if (pointUser < pointPc)
            {
                LblMsg.Text = "抱歉電腦獲勝 !!";
            }
            else
            {
                LblMsg.Text = "雙方平手 !!";
            }
        }
        // 每50毫秒(即0.05秒)執行一次TmrRun_Tick事件
        private void TmrRun_Tick(object sender, EventArgs e)
        {
            pointUser = rnd.Next(1, 14);//產生1~13變數
            PicUser.Image = ImgPoker.Images[pointUser - 1];
        }
    }
}
