﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Overload_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //取兩個整數的最小數
        private int GetMin(int x, int y)
        {
            if (x < y)
            {
                return x;
            }
            else
            {
                return y;
            }
        }
        //取浮點數陣列的最小數
        private double GetMin(ref double[] vArray)
        {
            double min = vArray[0];
            for (int i = 1; i <= vArray.GetUpperBound(0); i++)
            {
                if (vArray[i] < min)
                {
                    min = vArray[i];
                }
            }
            return min;
        }
        //取整數陣列的最小數
        private double GetMin(ref int[] vArray)
        {
            double min = vArray[0];
            for (int i = 1; i <= vArray.GetUpperBound(0); i++)
            {
                if (vArray[i] < min)
                {
                    min = vArray[i];
                }
            }
            return min;
        }
        //取三個整數的最小數
        private int GetMin(int x, int y, int z)
        {
            int min;
            if (x < y)
            {
                min = x;
            }
            else
            {
                min = y;
            }
            if (min > z)
            {
                min = z;
            }
            return min;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int a, b, c;
            a = 21; b = 14; c = 8;
            double[] arrD = new double[] { 12.1, 54.3, 7.2, 40 };
            int[] arrI = new int[] { 12, 10, 54, 7, 2, 40 };
            MessageBox.Show(a.ToString() + "和" + b.ToString() + "最小的數值為 : "
                            + GetMin(a, b).ToString());
            MessageBox.Show("陣列元素(12.1, 54.3, 7.2, 40)中最小的數值為 : "
                            + GetMin(ref arrD).ToString());
            MessageBox.Show("陣列元素(12, 10, 54, 7, 2, 40)中最小的數值為 : "
                            + GetMin(ref arrI).ToString());
            MessageBox.Show(a.ToString() + "、" + b.ToString() + "和" + c.ToString() + "最小的數值為 : "
                            + GetMin(a, b, c).ToString());
            Application.Exit();
        }
    }
}
