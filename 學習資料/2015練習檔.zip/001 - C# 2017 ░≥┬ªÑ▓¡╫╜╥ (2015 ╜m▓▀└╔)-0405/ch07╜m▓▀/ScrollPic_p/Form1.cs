﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScrollPic_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PicShow.SizeMode = PictureBoxSizeMode.StretchImage;
            PicShow.Height = 90; PicShow.Width = 90;    //設定圖片高度和寬度
            PicShow.Image = Image.FromFile("花.jpg");   //載入圖檔
            TkbPic.Maximum = 4; TkbPic.Minimum = 1;     //設定TkbPic的最大、最小值
                                                        //TkbHeight的Orientation屬性值設為Vertical使呈垂直
                                                        //TkbHeight的TickStyle屬性值設為TopLeft使尖端向左
                                                        //因為滑動軸為垂直時最小值在下方，為使和圖片方向一致
                                                        //所以將最大值設為-1、最小值為-180，Value值轉成正值就是圖片的高度
            TkbHeight.Maximum = -1; TkbHeight.Minimum = -180;//設定TkbHeight的最大、最小值
            TkbHeight.TickFrequency = 20;        //設刻度間距
            //TkbHeight.LargeChange = 1;         //滑動軸可以拖曳到最大值，所以可以省略
            TkbHeight.Value = -PicShow.Height;   //TkbHeight的Value值=圖片高度
            TkbWidth.Maximum = 180; TkbWidth.Minimum = 1;//設定TkbWidth的最大、最小值
            TkbWidth.TickFrequency = 20;        //設刻度間距
            //TkbWidth.LargeChange = 1;         //省略
            TkbWidth.Value = PicShow.Width;     //TkbWidth的Value值=圖片寬度
            //因為設定Value值時，會觸動ValueChange事件，所以下一列可以省略
            //LblH.Text = "高度=90"; LblW.Text = "寬度=90";
        }

        private void TkbHeight_ValueChanged(object sender, EventArgs e)
        {
            PicShow.Height = -TkbHeight.Value;     //設圖片高度=VsbHeight的Value值
            LblH.Text = "高度=" + (-TkbHeight.Value).ToString();
        }

        private void TkbWidth_ValueChanged(object sender, EventArgs e)
        {
            PicShow.Width = TkbWidth.Value;//設圖片寬度=HsbWidth的Value值
            LblW.Text = "寬度=" + TkbWidth.Value.ToString();
        }

        // 捲動滑動軸時執行
        private void TkbPic_ValueChanged(object sender, EventArgs e)
        {
            switch (TkbPic.Value)
            {
                case 1:
                    PicShow.Image = Image.FromFile("花.jpg");  //載入圖檔
                    break;
                case 2:
                    PicShow.Image = Image.FromFile("船.jpg");  //載入圖檔
                    break;
                case 3:
                    PicShow.Image = Image.FromFile("湖.jpg");  //載入圖檔
                    break;
                case 4:
                    PicShow.Image = Image.FromFile("纜車.jpg");  //載入圖檔
                    break;
            }
        }
    }
}
