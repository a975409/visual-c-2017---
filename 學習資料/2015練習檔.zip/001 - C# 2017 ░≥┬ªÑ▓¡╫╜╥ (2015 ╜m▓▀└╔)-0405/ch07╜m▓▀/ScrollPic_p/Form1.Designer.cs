﻿namespace ScrollPic_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.TkbHeight = new System.Windows.Forms.TrackBar();
            this.TkbWidth = new System.Windows.Forms.TrackBar();
            this.TkbPic = new System.Windows.Forms.TrackBar();
            this.LblW = new System.Windows.Forms.Label();
            this.LblH = new System.Windows.Forms.Label();
            this.PicShow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.TkbHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkbWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkbPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicShow)).BeginInit();
            this.SuspendLayout();
            // 
            // TkbHeight
            // 
            this.TkbHeight.Location = new System.Drawing.Point(219, 21);
            this.TkbHeight.Name = "TkbHeight";
            this.TkbHeight.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.TkbHeight.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TkbHeight.Size = new System.Drawing.Size(45, 191);
            this.TkbHeight.TabIndex = 30;
            this.TkbHeight.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.TkbHeight.ValueChanged += new System.EventHandler(this.TkbHeight_ValueChanged);
            // 
            // TkbWidth
            // 
            this.TkbWidth.Location = new System.Drawing.Point(15, 215);
            this.TkbWidth.Name = "TkbWidth";
            this.TkbWidth.Size = new System.Drawing.Size(195, 45);
            this.TkbWidth.TabIndex = 31;
            this.TkbWidth.ValueChanged += new System.EventHandler(this.TkbWidth_ValueChanged);
            // 
            // TkbPic
            // 
            this.TkbPic.Location = new System.Drawing.Point(15, 255);
            this.TkbPic.Name = "TkbPic";
            this.TkbPic.Size = new System.Drawing.Size(195, 45);
            this.TkbPic.TabIndex = 29;
            this.TkbPic.ValueChanged += new System.EventHandler(this.TkbPic_ValueChanged);
            // 
            // LblW
            // 
            this.LblW.AutoSize = true;
            this.LblW.Location = new System.Drawing.Point(217, 246);
            this.LblW.Name = "LblW";
            this.LblW.Size = new System.Drawing.Size(33, 12);
            this.LblW.TabIndex = 28;
            this.LblW.Text = "label2";
            // 
            // LblH
            // 
            this.LblH.AutoSize = true;
            this.LblH.Location = new System.Drawing.Point(216, 215);
            this.LblH.Name = "LblH";
            this.LblH.Size = new System.Drawing.Size(33, 12);
            this.LblH.TabIndex = 27;
            this.LblH.Text = "label1";
            // 
            // PicShow
            // 
            this.PicShow.Location = new System.Drawing.Point(30, 21);
            this.PicShow.Name = "PicShow";
            this.PicShow.Size = new System.Drawing.Size(180, 180);
            this.PicShow.TabIndex = 26;
            this.PicShow.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 293);
            this.Controls.Add(this.TkbHeight);
            this.Controls.Add(this.TkbWidth);
            this.Controls.Add(this.TkbPic);
            this.Controls.Add(this.LblW);
            this.Controls.Add(this.LblH);
            this.Controls.Add(this.PicShow);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TkbHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkbWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkbPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicShow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar TkbHeight;
        private System.Windows.Forms.TrackBar TkbWidth;
        private System.Windows.Forms.TrackBar TkbPic;
        private System.Windows.Forms.Label LblW;
        private System.Windows.Forms.Label LblH;
        private System.Windows.Forms.PictureBox PicShow;
    }
}

