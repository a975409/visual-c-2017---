﻿namespace Link_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TipWeb = new System.Windows.Forms.ToolTip(this.components);
            this.TipHelp = new System.Windows.Forms.ToolTip(this.components);
            this.LlblHelp = new System.Windows.Forms.LinkLabel();
            this.LlblWeb = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // LlblHelp
            // 
            this.LlblHelp.AutoSize = true;
            this.LlblHelp.Location = new System.Drawing.Point(166, 15);
            this.LlblHelp.Name = "LlblHelp";
            this.LlblHelp.Size = new System.Drawing.Size(53, 12);
            this.LlblHelp.TabIndex = 5;
            this.LlblHelp.TabStop = true;
            this.LlblHelp.Text = "說明事項";
            this.LlblHelp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LlblHelp_LinkClicked);
            // 
            // LlblWeb
            // 
            this.LlblWeb.AutoSize = true;
            this.LlblWeb.Font = new System.Drawing.Font("新細明體", 12F);
            this.LlblWeb.Location = new System.Drawing.Point(25, 76);
            this.LlblWeb.Name = "LlblWeb";
            this.LlblWeb.Size = new System.Drawing.Size(75, 16);
            this.LlblWeb.TabIndex = 4;
            this.LlblWeb.TabStop = true;
            this.LlblWeb.Text = "linkLabel1";
            this.LlblWeb.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LlblWeb_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 101);
            this.Controls.Add(this.LlblHelp);
            this.Controls.Add(this.LlblWeb);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip TipWeb;
        private System.Windows.Forms.ToolTip TipHelp;
        private System.Windows.Forms.LinkLabel LlblHelp;
        private System.Windows.Forms.LinkLabel LlblWeb;
    }
}

