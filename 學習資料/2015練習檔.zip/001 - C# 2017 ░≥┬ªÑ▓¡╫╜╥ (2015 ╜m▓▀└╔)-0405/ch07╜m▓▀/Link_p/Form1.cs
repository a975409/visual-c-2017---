﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Link_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //設定個控制項初值
        private void Form1_Load(object sender, EventArgs e)
        {
            LlblWeb.Links.RemoveAt(0); //用RemoveAt方法刪除預設的超連結
            LlblWeb.Text = "<<Google>><<Yahoo>><<PChome>>";
            LlblWeb.Links.Add(2, 6, "http://www.google.com");//設定"Google"六個字元具網頁超連結
            LlblWeb.Links.Add(12, 5, "http://tw.yahoo.com/");//設定"Yahoo"六個字元具網頁超連結
            LlblWeb.Links.Add(21, 6, "http://www.pchome.com.tw");//設定"Google"六個字元具網頁超連結
            LlblHelp.LinkArea = new LinkArea(0, 2);//設定"說明"兩三個字元具超連結
            TipWeb.IsBalloon = true;//設定使用氣球方式顯示
            TipWeb.ToolTipTitle = "常用網站：";//設定提示標題
            TipWeb.SetToolTip(LlblWeb, "1.Google\n2.奇摩雅虎\n3.PChome購物");//設定llblWeb的提示文字
            TipHelp.SetToolTip(LlblHelp, "開啟說明文件");//設定提示文字
        }
        //按LlblWeb超連結文字時
        private void LlblWeb_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());
        }
        //按LlblHelp超連結文字時
        private void LlblHelp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("help.txt");
        }
    }
}
