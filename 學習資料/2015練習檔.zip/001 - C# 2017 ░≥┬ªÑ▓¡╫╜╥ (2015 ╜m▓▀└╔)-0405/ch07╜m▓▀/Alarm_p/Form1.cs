﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alarm_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool onOff = false;    //記錄是否開啟鬧鈴，預設為False關閉
        private void Form1_Load(object sender, EventArgs e)
        {
            TmrNow.Interval = 100;  //每秒啟動計時器一次
            TmrNow.Enabled = true;  //啟動計時器
            DtpAlarm.Format = DateTimePickerFormat.Custom;//設dtpAlarm為自訂格式
            DtpAlarm.CustomFormat = "HH:mm";     //自訂格式為時：分
            DtpAlarm.ShowUpDown = true; //設按上下鈕設定時間
        }

        private void TmrNow_Tick(object sender, EventArgs e)
        {
            LblTime.Text = DateTime.Now.ToLongTimeString(); //顯示現在時間
            //若onOff = True 而且現在時間大於鬧鈴時間 且小於鬧鈴時間加6分鐘
            if (onOff == true && (DateTime.Now >= DtpAlarm.Value && DateTime.Now <= DtpAlarm.Value.AddMinutes(6)))
            {
                System.Media.SystemSounds.Beep.Play();  //發出系統Beep聲
            }
        }

        private void BtnAlarm_Click(object sender, EventArgs e)
        {
            onOff = !onOff;  //onOff做Not運算
            //根據onOff值，設定按鈕的文字
            BtnAlarm.Text = onOff == true ? "關閉鬧鈴" : "開啟鬧鈴";
        }

        private void BtnLate_Click(object sender, EventArgs e)
        {
            if (onOff == true)  //若鬧鈴在響
            {
                DtpAlarm.Value = DtpAlarm.Value.AddMinutes(10);   //鬧鈴加10分鐘        
            }
        }
    }
}
