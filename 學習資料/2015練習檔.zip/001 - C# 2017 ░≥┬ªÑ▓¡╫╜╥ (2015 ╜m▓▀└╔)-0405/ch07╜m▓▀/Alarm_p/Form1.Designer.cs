﻿namespace Alarm_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnLate = new System.Windows.Forms.Button();
            this.BtnAlarm = new System.Windows.Forms.Button();
            this.DtpAlarm = new System.Windows.Forms.DateTimePicker();
            this.Label2 = new System.Windows.Forms.Label();
            this.LblTime = new System.Windows.Forms.Label();
            this.TmrNow = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // BtnLate
            // 
            this.BtnLate.Location = new System.Drawing.Point(187, 103);
            this.BtnLate.Name = "BtnLate";
            this.BtnLate.Size = new System.Drawing.Size(75, 23);
            this.BtnLate.TabIndex = 24;
            this.BtnLate.Text = "貪睡十分鐘";
            this.BtnLate.UseVisualStyleBackColor = true;
            this.BtnLate.Click += new System.EventHandler(this.BtnLate_Click);
            // 
            // BtnAlarm
            // 
            this.BtnAlarm.Location = new System.Drawing.Point(100, 103);
            this.BtnAlarm.Name = "BtnAlarm";
            this.BtnAlarm.Size = new System.Drawing.Size(75, 23);
            this.BtnAlarm.TabIndex = 23;
            this.BtnAlarm.Text = "開啟鬧鈴";
            this.BtnAlarm.UseVisualStyleBackColor = true;
            this.BtnAlarm.Click += new System.EventHandler(this.BtnAlarm_Click);
            // 
            // DtpAlarm
            // 
            this.DtpAlarm.Location = new System.Drawing.Point(31, 139);
            this.DtpAlarm.Name = "DtpAlarm";
            this.DtpAlarm.Size = new System.Drawing.Size(200, 22);
            this.DtpAlarm.TabIndex = 22;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(29, 108);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(65, 12);
            this.Label2.TabIndex = 21;
            this.Label2.Text = "鬧鈴時間：";
            // 
            // LblTime
            // 
            this.LblTime.BackColor = System.Drawing.Color.Black;
            this.LblTime.Font = new System.Drawing.Font("Arial", 20F);
            this.LblTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.LblTime.Location = new System.Drawing.Point(22, 20);
            this.LblTime.Name = "LblTime";
            this.LblTime.Size = new System.Drawing.Size(221, 59);
            this.LblTime.TabIndex = 20;
            this.LblTime.Text = "Label1";
            this.LblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TmrNow
            // 
            this.TmrNow.Tick += new System.EventHandler(this.TmrNow_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 181);
            this.Controls.Add(this.BtnLate);
            this.Controls.Add(this.BtnAlarm);
            this.Controls.Add(this.DtpAlarm);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.LblTime);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button BtnLate;
        internal System.Windows.Forms.Button BtnAlarm;
        internal System.Windows.Forms.DateTimePicker DtpAlarm;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label LblTime;
        internal System.Windows.Forms.Timer TmrNow;
    }
}

