﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryDemoP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtInput.MaxLength = 3;
            TxtInput.TabIndex = 0;
            TxtAns.ReadOnly = true;
            TxtAns.TabStop = false;
            TxtInput.Focus();
        }

        private void BtnC2F_Click(object sender, EventArgs e)
        {
            try
            {
                double c = Convert.ToDouble(TxtInput.Text);  //數字字串轉換成Double
                double f = c * 9 / 5 + 32;  //計算出華氏溫度
                TxtAns.Text = "華氏 " + f.ToString("F2") + " 度";  //顯示華氏溫度
            }
            catch
            {
                TxtAns.Text = "請輸入數值!";  //顯示提示訊息
                TxtInput.Clear();  //清空文字內容
            }
            TxtInput.Focus();
        }

        private void BtnF2C_Click(object sender, EventArgs e)
        {
            try
            {
                double f = Convert.ToDouble(TxtInput.Text);  //數字字串轉換成Double
                double c = (f - 32) * 5 / 9;  //計算出攝氏溫度
                TxtAns.Text = "攝氏 " + c.ToString("F2") + " 度";  //顯示攝氏溫度
            }
            catch
            {
                TxtAns.Text = "請輸入數值!";  //顯示提示訊息
                TxtInput.Clear();  //清空文字內容
            }
            TxtInput.Focus();
        }
    }
}
