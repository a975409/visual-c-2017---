﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtQtyF.Text = "0";
            TxtQtyH.Text = "0";
            TxtQtyF.Focus();  //預設全票文字方塊取得駐停焦點
        }
        // 全票文字方塊取得駐停焦點時執行
        private void TxtQtyF_Enter(object sender, EventArgs e)
        {
            TxtQtyF.Text = "";
        }
        // 優待票文字方塊取得駐停焦點時執行
        private void TxtQtyH_Enter(object sender, EventArgs e)
        {
            TxtQtyH.Text = "";
        }

        private void TxtQtyF_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int sumF, total;
                //計算全票總金額
                sumF = Convert.ToInt32(LblPriceF.Text) * Convert.ToInt32(TxtQtyF.Text);
                LblSumF.Text = Convert.ToString(sumF);  //顯示全票總金額
                total = sumF + Convert.ToInt32(LblSumH.Text);  //全票總金額加上優待票總金額
                LblTotal.Text = Convert.ToString(total);  //顯示全票與優待票合計
            }
            catch
            {
                LblSumF.Text = "0";
            }
        }

        private void TxtQtyH_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int sumH, sum;
                //計算優待票總金額
                sumH = Convert.ToInt32(LblPriceH.Text) * Convert.ToInt32(TxtQtyH.Text);
                LblSumH.Text = Convert.ToString(sumH);  //顯示全票總金額
                sum = sumH + Convert.ToInt32(LblSumF.Text);  //全票總金額加上優待票總金額
                LblTotal.Text = Convert.ToString(sum);  //顯示全票與優待票合計
            }
            catch
            {
                TxtQtyH.Text = "0";
            }
        }
    }
}
