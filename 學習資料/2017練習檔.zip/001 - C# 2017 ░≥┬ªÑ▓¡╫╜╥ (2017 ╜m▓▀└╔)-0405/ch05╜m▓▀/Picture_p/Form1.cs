﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Picture_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PicDemo1.SizeMode = PictureBoxSizeMode.StretchImage;//設隨控制項調整圖片大小
            PicDemo2.SizeMode = PictureBoxSizeMode.StretchImage;
            PicDemo3.SizeMode = PictureBoxSizeMode.StretchImage;
            PicDemo4.SizeMode = PictureBoxSizeMode.StretchImage;
            PicDemo1.Image = new Bitmap("pic1.jpg");    //載入圖檔
            PicDemo2.Image = new Bitmap("pic2.jpg");
            PicDemo3.Image = new Bitmap("pic3.jpg");
            PicDemo4.Image = new Bitmap("pic4.jpg");
            PicShow.Image = PicDemo1.Image;	//預設顯示picDemo1的圖形
        }
        //picShow控制項展開的方法
        private void Stretch()
        {
            for (int w = 0; w <= 250; w += 10)   //控制項寬度由0到250，間距為10
            {
                PicShow.Size = new Size(w,200);    //重設大小
                PicShow.Location = new Point(265 - w, 45);
                DateTime now = DateTime.Now;    //now記錄目前時間
                do     //時間間隔 < 0.1秒
                {
                    Application.DoEvents();       //處理其他事件
                } while ((DateTime.Now - now).TotalSeconds < 0.1);
            }
        }
        //按picDemo1控制項時
        private void PicDemo1_Click(object sender, EventArgs e)
        {
            PicShow.Image = PicDemo1.Image; //設顯示picDemo1的圖形
            Stretch();  //執行Stretch方法
        }
        //按picDemo2控制項時
        private void PicDemo2_Click(object sender, EventArgs e)
        {
            PicShow.Image = PicDemo2.Image; //設顯示picDemo2的圖形
            Stretch();  //執行Stretch方法
        }
        //按picDemo3控制項時
        private void PicDemo3_Click(object sender, EventArgs e)
        {
            PicShow.Image = PicDemo3.Image; //設顯示picDemo3的圖形
            Stretch();  //執行Stretch方法
        }
        //按picDemo4控制項時
        private void PicDemo4_Click(object sender, EventArgs e)
        {
            PicShow.Image = PicDemo4.Image; //設顯示picDemo4的圖形
            Stretch();  //執行Stretch方法
        }
    }
}
