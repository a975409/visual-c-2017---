﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Score_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string str = string.Empty;
            for (int i = 1; i <= 6; i++)
            {
                for (int j = 1; j <=i; j++)
                {
                    str += i + "x" + j + "=" + (i * j) + '\t';
                }
                str += '\n';
            }
            MessageBox.Show(str);
            Application.Exit();
        }
    }
}
