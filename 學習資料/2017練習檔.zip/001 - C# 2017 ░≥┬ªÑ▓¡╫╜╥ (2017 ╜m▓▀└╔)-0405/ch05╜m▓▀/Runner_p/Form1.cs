﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Runner_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int num;    //紀錄圖片的註標值
        private void Form1_Load(object sender, EventArgs e)
        {
            num = 0;    //預設圖片的註標值為0
            PicRun.SizeMode = PictureBoxSizeMode.StretchImage;//圖片調成和控制項同大小
            TmrRun.Interval = 200;  //tmrRun間隔為0.2秒
            TmrRun.Enabled = true;  //啟動tmrRun計時器
            TmrMove.Interval = 100; //tmrMove間隔為0.1秒
        }
        //在tmrRun_Tick事件中輪流播放四張圖片
        private void TmrRun_Tick(object sender, EventArgs e)
        {
            PicRun.Image = ImgRun.Images[num];
            if (num == 3)   //若圖片註標值 = 3
                num = 0;    //設圖片註標值 = 0
            else            //其餘即圖片註標值 < 3
                num++;		//圖片註標值加 1
        }
        //在tmrMove_Tick事件中將picRun左移10點
        private void TmrMove_Tick(object sender, EventArgs e)
        {
            PicRun.Left -= 10;  //picRun左移10點
                                //若picRun的Left <= -45，就設picRun.Left等於表單工作區的寬度
            if (PicRun.Left <= -45) PicRun.Left = this.ClientSize.Width;
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            TmrMove.Enabled = true; //啟動tmrMove計時器
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            TmrMove.Enabled = false; //關閉tmrMove計時器
        }
    }
}
