﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace For1_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 11; i >=1; i-=2)
            {
                sum += i;
            }
            MessageBox.Show(sum.ToString());
            Application.Exit();
        }
    }
}
