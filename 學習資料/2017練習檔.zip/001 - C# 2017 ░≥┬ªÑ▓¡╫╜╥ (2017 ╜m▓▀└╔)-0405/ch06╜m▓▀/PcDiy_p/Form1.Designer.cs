﻿namespace PcDiy_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.CblDevice = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LblSum = new System.Windows.Forms.Label();
            this.CbxCRT = new System.Windows.Forms.ComboBox();
            this.LstPC = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LstBuy = new System.Windows.Forms.ListBox();
            this.BtnOK = new System.Windows.Forms.Button();
            this.BtnNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CblDevice
            // 
            this.CblDevice.FormattingEnabled = true;
            this.CblDevice.Location = new System.Drawing.Point(144, 64);
            this.CblDevice.Name = "CblDevice";
            this.CblDevice.Size = new System.Drawing.Size(121, 72);
            this.CblDevice.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(142, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 27;
            this.label4.Text = "週邊配備";
            // 
            // LblSum
            // 
            this.LblSum.AutoSize = true;
            this.LblSum.Location = new System.Drawing.Point(278, 130);
            this.LblSum.Name = "LblSum";
            this.LblSum.Size = new System.Drawing.Size(41, 12);
            this.LblSum.TabIndex = 26;
            this.LblSum.Text = "合計：";
            // 
            // CbxCRT
            // 
            this.CbxCRT.FormattingEnabled = true;
            this.CbxCRT.Location = new System.Drawing.Point(144, 26);
            this.CbxCRT.Name = "CbxCRT";
            this.CbxCRT.Size = new System.Drawing.Size(121, 20);
            this.CbxCRT.TabIndex = 25;
            // 
            // LstPC
            // 
            this.LstPC.FormattingEnabled = true;
            this.LstPC.ItemHeight = 12;
            this.LstPC.Location = new System.Drawing.Point(11, 26);
            this.LstPC.Name = "LstPC";
            this.LstPC.Size = new System.Drawing.Size(120, 76);
            this.LstPC.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(142, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 23;
            this.label3.Text = "液晶螢幕尺寸";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "主機廠牌";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(286, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 29;
            this.label1.Text = "購物籃";
            // 
            // LstBuy
            // 
            this.LstBuy.FormattingEnabled = true;
            this.LstBuy.ItemHeight = 12;
            this.LstBuy.Location = new System.Drawing.Point(280, 26);
            this.LstBuy.Name = "LstBuy";
            this.LstBuy.Size = new System.Drawing.Size(132, 100);
            this.LstBuy.TabIndex = 24;
            // 
            // BtnOK
            // 
            this.BtnOK.Location = new System.Drawing.Point(12, 119);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(50, 23);
            this.BtnOK.TabIndex = 30;
            this.BtnOK.Text = "確定";
            this.BtnOK.UseVisualStyleBackColor = true;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // BtnNew
            // 
            this.BtnNew.Location = new System.Drawing.Point(81, 119);
            this.BtnNew.Name = "BtnNew";
            this.BtnNew.Size = new System.Drawing.Size(50, 23);
            this.BtnNew.TabIndex = 30;
            this.BtnNew.Text = "重新";
            this.BtnNew.UseVisualStyleBackColor = true;
            this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 161);
            this.Controls.Add(this.BtnNew);
            this.Controls.Add(this.BtnOK);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CblDevice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LblSum);
            this.Controls.Add(this.CbxCRT);
            this.Controls.Add(this.LstBuy);
            this.Controls.Add(this.LstPC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "PC DIY 試算";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox CblDevice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label LblSum;
        private System.Windows.Forms.ComboBox CbxCRT;
        private System.Windows.Forms.ListBox LstPC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox LstBuy;
        private System.Windows.Forms.Button BtnOK;
        private System.Windows.Forms.Button BtnNew;
    }
}

