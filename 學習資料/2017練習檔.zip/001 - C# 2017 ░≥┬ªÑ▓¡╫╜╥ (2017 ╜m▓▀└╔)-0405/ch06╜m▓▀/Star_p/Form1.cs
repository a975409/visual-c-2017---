﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Star_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int n = 0;  //目前第n位老師的給分
        string[] tea = new string[] { "丁曉雯", "羅文聰",
            "陳盈潔", "左安安", "許景淳"};  //宣告tea陣列存放評審老師姓名
        int[] score = new int[5];           //宣告score[0]~[4]存放五位老師的給分
        private void Form1_Load(object sender, EventArgs e)
        {
            LblScore.Text = tea[n] + "老師給分：";
            LblMsg.Text = "";       //清空lblMsg
        }
        //按下 確定 鈕時
        private void BtnOK_Click(object sender, EventArgs e)
        {
            try
            {
                score[n] = Convert.ToInt32(TxtScore.Text);//將分數存入對應的陣列元素中
            }
            catch (Exception)
            {
                TxtScore.Text = "";     //給分清空
                TxtScore.Focus();       //焦點移入
                return;
            }
            if (score[n] > 100 || score[n] < 0) return; //分數超出範圍就離開
            LblMsg.Text = "";   //清空分數顯示
            // 在lblMsg標籤印出0~n筆分數
            for (int i = 0; i <= n; i++)
            {
                LblMsg.Text += tea[i] + "老師給分：" + score[i].ToString() + "\n";
            }
            n++;    //n加1
            if (n == 5)   // 判斷是否已輸入5筆成績
            {
                double sum = 0; //紀錄總分
                foreach (int s in score) //計算五筆分數的總和
                {
                    sum += s;
                }
                LblMsg.Text += "=================\n";
                LblMsg.Text += "平均分數：" + (sum / 5).ToString() + "\n";
                BtnOK.Enabled = false;  // 確定鈕不能使用
            }
            else
            {
                LblScore.Text = tea[n] + "老師給分：";
                TxtScore.Text = "";     //給分清空
                TxtScore.Focus();       //焦點移入
            }
        }
        //按下 重新 鈕時
        private void BtnNew_Click(object sender, EventArgs e)
        {
            n = 0;
            LblScore.Text = tea[n] + "老師給分：";
            TxtScore.Text = "";     //給分清空
            TxtScore.Focus();       //焦點移入
            LblMsg.Text = "";       //清空lblMsg
            for (int i = 0; i < score.Length; i++)
            {
                score[i] = 0;       //將分數重設為0
            }
            BtnOK.Enabled = true;   // 確定鈕可以使用
        }
    }
}
