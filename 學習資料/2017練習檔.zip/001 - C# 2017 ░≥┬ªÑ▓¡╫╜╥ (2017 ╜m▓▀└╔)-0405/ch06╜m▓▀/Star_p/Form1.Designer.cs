﻿namespace Star_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.LblMsg = new System.Windows.Forms.Label();
            this.BtnOK = new System.Windows.Forms.Button();
            this.TxtScore = new System.Windows.Forms.TextBox();
            this.LblScore = new System.Windows.Forms.Label();
            this.BtnNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblMsg
            // 
            this.LblMsg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblMsg.Location = new System.Drawing.Point(24, 75);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(235, 108);
            this.LblMsg.TabIndex = 17;
            this.LblMsg.Text = "label2";
            // 
            // BtnOK
            // 
            this.BtnOK.Location = new System.Drawing.Point(184, 37);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(75, 23);
            this.BtnOK.TabIndex = 16;
            this.BtnOK.Text = "確定";
            this.BtnOK.UseVisualStyleBackColor = true;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // TxtScore
            // 
            this.TxtScore.Location = new System.Drawing.Point(23, 39);
            this.TxtScore.Name = "TxtScore";
            this.TxtScore.Size = new System.Drawing.Size(100, 22);
            this.TxtScore.TabIndex = 15;
            // 
            // LblScore
            // 
            this.LblScore.AutoSize = true;
            this.LblScore.Location = new System.Drawing.Point(22, 12);
            this.LblScore.Name = "LblScore";
            this.LblScore.Size = new System.Drawing.Size(33, 12);
            this.LblScore.TabIndex = 14;
            this.LblScore.Text = "label1";
            // 
            // BtnNew
            // 
            this.BtnNew.Location = new System.Drawing.Point(184, 186);
            this.BtnNew.Name = "BtnNew";
            this.BtnNew.Size = new System.Drawing.Size(75, 23);
            this.BtnNew.TabIndex = 18;
            this.BtnNew.Text = "重新";
            this.BtnNew.UseVisualStyleBackColor = true;
            this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 221);
            this.Controls.Add(this.BtnNew);
            this.Controls.Add(this.LblMsg);
            this.Controls.Add(this.BtnOK);
            this.Controls.Add(this.TxtScore);
            this.Controls.Add(this.LblScore);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblMsg;
        private System.Windows.Forms.Button BtnOK;
        private System.Windows.Forms.TextBox TxtScore;
        private System.Windows.Forms.Label LblScore;
        private System.Windows.Forms.Button BtnNew;
    }
}

