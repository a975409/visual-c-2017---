﻿namespace Song_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSortNoRe = new System.Windows.Forms.Button();
            this.BtnSortSinger = new System.Windows.Forms.Button();
            this.BtnSortNo = new System.Windows.Forms.Button();
            this.TxtMsg = new System.Windows.Forms.TextBox();
            this.TxtSinger = new System.Windows.Forms.TextBox();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.BtnSortSong = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnSortNoRe
            // 
            this.BtnSortNoRe.Location = new System.Drawing.Point(280, 136);
            this.BtnSortNoRe.Name = "BtnSortNoRe";
            this.BtnSortNoRe.Size = new System.Drawing.Size(75, 23);
            this.BtnSortNoRe.TabIndex = 27;
            this.BtnSortNoRe.Text = "依排名遞減";
            this.BtnSortNoRe.UseVisualStyleBackColor = true;
            this.BtnSortNoRe.Click += new System.EventHandler(this.BtnSortNoRe_Click);
            // 
            // BtnSortSinger
            // 
            this.BtnSortSinger.Location = new System.Drawing.Point(280, 94);
            this.BtnSortSinger.Name = "BtnSortSinger";
            this.BtnSortSinger.Size = new System.Drawing.Size(75, 23);
            this.BtnSortSinger.TabIndex = 26;
            this.BtnSortSinger.Text = "依歌手排序";
            this.BtnSortSinger.UseVisualStyleBackColor = true;
            this.BtnSortSinger.Click += new System.EventHandler(this.BtnSortSinger_Click);
            // 
            // BtnSortNo
            // 
            this.BtnSortNo.Location = new System.Drawing.Point(280, 12);
            this.BtnSortNo.Name = "BtnSortNo";
            this.BtnSortNo.Size = new System.Drawing.Size(75, 23);
            this.BtnSortNo.TabIndex = 21;
            this.BtnSortNo.Text = "依排名排序";
            this.BtnSortNo.UseVisualStyleBackColor = true;
            this.BtnSortNo.Click += new System.EventHandler(this.BtnSortNo_Click);
            // 
            // TxtMsg
            // 
            this.TxtMsg.Location = new System.Drawing.Point(15, 12);
            this.TxtMsg.Multiline = true;
            this.TxtMsg.Name = "TxtMsg";
            this.TxtMsg.ReadOnly = true;
            this.TxtMsg.Size = new System.Drawing.Size(221, 157);
            this.TxtMsg.TabIndex = 24;
            // 
            // TxtSinger
            // 
            this.TxtSinger.Location = new System.Drawing.Point(162, 185);
            this.TxtSinger.Name = "TxtSinger";
            this.TxtSinger.Size = new System.Drawing.Size(100, 22);
            this.TxtSinger.TabIndex = 23;
            // 
            // BtnSearch
            // 
            this.BtnSearch.Location = new System.Drawing.Point(280, 183);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(75, 23);
            this.BtnSearch.TabIndex = 22;
            this.BtnSearch.Text = "查詢歌手";
            this.BtnSearch.UseVisualStyleBackColor = true;
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // BtnSortSong
            // 
            this.BtnSortSong.Location = new System.Drawing.Point(280, 53);
            this.BtnSortSong.Name = "BtnSortSong";
            this.BtnSortSong.Size = new System.Drawing.Size(75, 23);
            this.BtnSortSong.TabIndex = 25;
            this.BtnSortSong.Text = "依歌曲排序";
            this.BtnSortSong.UseVisualStyleBackColor = true;
            this.BtnSortSong.Click += new System.EventHandler(this.BtnSortSong_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 219);
            this.Controls.Add(this.BtnSortNoRe);
            this.Controls.Add(this.BtnSortSinger);
            this.Controls.Add(this.BtnSortNo);
            this.Controls.Add(this.TxtMsg);
            this.Controls.Add(this.TxtSinger);
            this.Controls.Add(this.BtnSearch);
            this.Controls.Add(this.BtnSortSong);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSortNoRe;
        private System.Windows.Forms.Button BtnSortSinger;
        private System.Windows.Forms.Button BtnSortNo;
        private System.Windows.Forms.TextBox TxtMsg;
        private System.Windows.Forms.TextBox TxtSinger;
        private System.Windows.Forms.Button BtnSearch;
        private System.Windows.Forms.Button BtnSortSong;
    }
}

