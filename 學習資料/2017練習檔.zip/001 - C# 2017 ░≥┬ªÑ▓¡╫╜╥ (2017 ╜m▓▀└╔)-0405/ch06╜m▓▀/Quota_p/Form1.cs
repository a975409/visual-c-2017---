﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quota_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   //陣列存放營業處名稱
            string[] company = new string[] { "台北", "台中", "高雄" };
            int[,] amt = new int[,] {{1000, 2000, 3000, 4000},
                    {1500, 2500, 3500, 4500}, {3200, 1800, 3600, 1400}};//各營業處各季營業額
            int[] sum = new int[4]; //各季總營業額
            // 計算四季各營業處業績合計置入 sum[i]
            for (int i = 0; i <= amt.GetUpperBound(1); i++)
            {
                for (int k = 0; k <= amt.GetUpperBound(0); k++)
                {
                    sum[i] += amt[k, i];
                }
            }
            //  標題顯示在文字方塊控制項
            string msg = "營業處\t";
            foreach (string c in company)   //讀取營業處名稱
            {
                msg += c + "\t";
            }
            msg+="合計\n\n";
            // 逐列顯示各季的名稱、台北、台中、高雄、總營業額
            for (int i = 0; i <= amt.GetUpperBound(1); i++)
            {
                msg += "第"+ (i+1) +"季\t";
                for (int k = 0; k <= amt.GetUpperBound(0); k++)
                {
                    msg += amt[k, i].ToString() + "\t";
                }
                msg += Convert.ToString(sum[i]) + "\n";
            }
            MessageBox.Show(msg, "營業報表");
            Application.Exit();
        }
    }
}
