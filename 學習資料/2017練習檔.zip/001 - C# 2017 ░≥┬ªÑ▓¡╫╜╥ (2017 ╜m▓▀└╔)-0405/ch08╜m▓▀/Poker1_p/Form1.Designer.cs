﻿namespace Poker1_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnStart = new System.Windows.Forms.Button();
            this.PicPc = new System.Windows.Forms.PictureBox();
            this.LblMsg = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TmrRun = new System.Windows.Forms.Timer(this.components);
            this.ImgPoker = new System.Windows.Forms.ImageList(this.components);
            this.PicUser = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PicPc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicUser)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(155, 220);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(70, 31);
            this.BtnStop.TabIndex = 35;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnStart
            // 
            this.BtnStart.Location = new System.Drawing.Point(56, 220);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(70, 31);
            this.BtnStart.TabIndex = 34;
            this.BtnStart.Text = "開始";
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // PicPc
            // 
            this.PicPc.Location = new System.Drawing.Point(34, 67);
            this.PicPc.Name = "PicPc";
            this.PicPc.Size = new System.Drawing.Size(71, 96);
            this.PicPc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PicPc.TabIndex = 33;
            this.PicPc.TabStop = false;
            // 
            // LblMsg
            // 
            this.LblMsg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LblMsg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblMsg.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LblMsg.Location = new System.Drawing.Point(34, 175);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(216, 33);
            this.LblMsg.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(34, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 26);
            this.label1.TabIndex = 31;
            this.label1.Text = "樸克牌比大小遊戲";
            // 
            // TmrRun
            // 
            this.TmrRun.Tick += new System.EventHandler(this.TmrRun_Tick);
            // 
            // ImgPoker
            // 
            this.ImgPoker.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImgPoker.ImageStream")));
            this.ImgPoker.TransparentColor = System.Drawing.Color.Transparent;
            this.ImgPoker.Images.SetKeyName(0, "poker1.jpg");
            this.ImgPoker.Images.SetKeyName(1, "poker2.jpg");
            this.ImgPoker.Images.SetKeyName(2, "poker3.jpg");
            this.ImgPoker.Images.SetKeyName(3, "poker4.jpg");
            this.ImgPoker.Images.SetKeyName(4, "poker5.jpg");
            this.ImgPoker.Images.SetKeyName(5, "poker6.jpg");
            this.ImgPoker.Images.SetKeyName(6, "poker7.jpg");
            this.ImgPoker.Images.SetKeyName(7, "poker8.jpg");
            this.ImgPoker.Images.SetKeyName(8, "poker9.jpg");
            this.ImgPoker.Images.SetKeyName(9, "poker10.jpg");
            this.ImgPoker.Images.SetKeyName(10, "poker11.jpg");
            this.ImgPoker.Images.SetKeyName(11, "poker12.jpg");
            this.ImgPoker.Images.SetKeyName(12, "poker13.jpg");
            // 
            // PicUser
            // 
            this.PicUser.Location = new System.Drawing.Point(167, 67);
            this.PicUser.Name = "PicUser";
            this.PicUser.Size = new System.Drawing.Size(71, 96);
            this.PicUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PicUser.TabIndex = 33;
            this.PicUser.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 36;
            this.label2.Text = "電腦：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(165, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 36;
            this.label3.Text = "玩家：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnStop);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.PicUser);
            this.Controls.Add(this.PicPc);
            this.Controls.Add(this.LblMsg);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicPc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.PictureBox PicPc;
        private System.Windows.Forms.Label LblMsg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer TmrRun;
        private System.Windows.Forms.ImageList ImgPoker;
        private System.Windows.Forms.PictureBox PicUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

