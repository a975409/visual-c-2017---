﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guess_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] pName = new string[] { "剪刀", "石頭", "布" };
        int userW = 0, pcW = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            Button[] arrBtn = new Button[3];
            arrBtn[0] = Btn1; arrBtn[1] = Btn2; arrBtn[2] = Btn3;
            for (int i = 0; i < 3; i++)
            {
                arrBtn[i].Text = pName[i]; //設定文字內容
                arrBtn[i].Image = new Bitmap(arrBtn[i].Text + ".gif");//顯示對應圖檔
                arrBtn[i].Click += MyClick;//共用MyClick事件
            }
            LblMsg.Text = "請按鈕出拳！";
            LblUser.Text = "你獲勝" + userW.ToString() + "次";
            LblPc.Text = "電腦獲勝" + pcW.ToString() + "次";
        }
        //Btn1、Btn2、Btn3的Click事件共用事件
        private void MyClick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int p = rnd.Next(0, 3);//產生0~2變數
            PicPc.Image = Image.FromFile(pName[p] + ".gif");//顯示電腦出拳
            Button btnHit = (Button)sender;//取得目前的按鈕
                                           //呼叫GetWinner方法來判斷誰獲勝
            LblMsg.Text = GetWinner(btnHit.Text, pName[p]);
            LblUser.Text = "你獲勝" + userW.ToString() + "次";
            LblPc.Text = "電腦獲勝" + pcW.ToString() + "次";
        }
        //GetWinner方法可以傳回誰獲勝
        private string GetWinner(string user, string pc)
        {
            string msg = "";
            if (user == pc)
            {
                return "雙方平手！";
            }
            else if (user == "剪刀")
            {
                if (pc == "石頭")
                {
                    msg = "電腦獲勝！";
                    pcW++;
                }
                else
                {
                    msg = "你獲勝！";
                    userW++;
                }
            }
            else if (user == "石頭")
            {
                if (pc == "布")
                {
                    msg = "電腦獲勝！";
                    pcW++;
                }
                else
                {
                    msg = "你獲勝！";
                    userW++;
                } 
            }
            else
            {
                if (pc == "剪刀")
                {
                    msg = "電腦獲勝！";
                    pcW++;
                }
                else
                {
                    msg = "你獲勝！";
                    userW++;
                }
            }
            return msg;
        }
    }
}