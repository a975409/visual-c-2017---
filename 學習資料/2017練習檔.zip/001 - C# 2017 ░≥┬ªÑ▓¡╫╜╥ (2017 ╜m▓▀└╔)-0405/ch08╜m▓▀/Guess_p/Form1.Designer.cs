﻿namespace Guess_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LblPc = new System.Windows.Forms.Label();
            this.LblUser = new System.Windows.Forms.Label();
            this.LblMsg = new System.Windows.Forms.Label();
            this.PicPc = new System.Windows.Forms.PictureBox();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PicPc)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "電腦出拳：";
            // 
            // LblPc
            // 
            this.LblPc.AutoSize = true;
            this.LblPc.Location = new System.Drawing.Point(192, 161);
            this.LblPc.Name = "LblPc";
            this.LblPc.Size = new System.Drawing.Size(33, 12);
            this.LblPc.TabIndex = 17;
            this.LblPc.Text = "label2";
            // 
            // LblUser
            // 
            this.LblUser.AutoSize = true;
            this.LblUser.Location = new System.Drawing.Point(192, 138);
            this.LblUser.Name = "LblUser";
            this.LblUser.Size = new System.Drawing.Size(33, 12);
            this.LblUser.TabIndex = 16;
            this.LblUser.Text = "label1";
            // 
            // LblMsg
            // 
            this.LblMsg.AutoSize = true;
            this.LblMsg.Location = new System.Drawing.Point(192, 113);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(33, 12);
            this.LblMsg.TabIndex = 15;
            this.LblMsg.Text = "label1";
            // 
            // PicPc
            // 
            this.PicPc.Location = new System.Drawing.Point(105, 103);
            this.PicPc.Name = "PicPc";
            this.PicPc.Size = new System.Drawing.Size(70, 70);
            this.PicPc.TabIndex = 14;
            this.PicPc.TabStop = false;
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(194, 18);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(70, 70);
            this.Btn3.TabIndex = 11;
            this.Btn3.Text = "button3";
            this.Btn3.UseVisualStyleBackColor = true;
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(104, 18);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(70, 70);
            this.Btn2.TabIndex = 12;
            this.Btn2.Text = "button2";
            this.Btn2.UseVisualStyleBackColor = true;
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(20, 18);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(70, 70);
            this.Btn1.TabIndex = 13;
            this.Btn1.Text = "button1";
            this.Btn1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 191);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblPc);
            this.Controls.Add(this.LblUser);
            this.Controls.Add(this.LblMsg);
            this.Controls.Add(this.PicPc);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicPc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblPc;
        private System.Windows.Forms.Label LblUser;
        private System.Windows.Forms.Label LblMsg;
        private System.Windows.Forms.PictureBox PicPc;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn1;
    }
}

