﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RndArray_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //根據陣列大小產生n1到n2範圍內不重複的亂數值
        private void SetDifRndNum(int[] arrNum, int n1, int n2)
        {
            Random r = new Random();            //建立r亂數物件
            int rNum;   //存放產生的亂數
            for (int i = 0; i <= arrNum.Length - 1; i++)    //逐一產生亂數
            {
                rNum = r.Next(n1, n2 + 1);  //產生n1~n2亂數
                bool same = false;          //檢查亂數是否重複，預設為不重複
                foreach (int n in arrNum)   //逐一檢查arrNum陣列元素
                {
                    if (rNum == n) { same = true; break; }  //若相同就設same=true並離開迴圈
                    if (n == 0) { same = false; break; }    //若是0表沒亂數設same=false離開迴圈
                }
                if (same == false)          //若same=false
                    arrNum[i] = rNum;       //將亂數存入陣列中
                else
                    i--;					//i減1重新產生亂數
            }
        }
        //顯示傳入整數陣列內的元素值
        private void ShowArray(ref int[] arr)
        {
            string msg = "";
            foreach (int a in arr)          //逐一讀取陣列元素值
            {
                msg += a.ToString() + "\n"; //將元素值加入msg字串中
            }
            MessageBox.Show(msg);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int[] arrRnd = new int[4];  //宣告整數陣列arrRnd大小為4
            SetDifRndNum(arrRnd, 1, 49);//呼叫SetDifRndNum方法產生1~49不重複的亂數
            ShowArray(ref arrRnd);      //呼叫ShowArray方法來顯示陣列元素值
            Application.Exit();
        }

    }
}
