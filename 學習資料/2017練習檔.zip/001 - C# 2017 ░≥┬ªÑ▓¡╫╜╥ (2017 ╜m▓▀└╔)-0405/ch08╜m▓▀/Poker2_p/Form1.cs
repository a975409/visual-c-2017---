﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poker2_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int pointPc, pointUser;  // 宣告point整數欄位變數來存放得到的點數
        Random rnd = new Random();  //亂數物件
        PictureBox[] arrPc = new PictureBox[3]; //圖片控制項陣列arrPc
        PictureBox[] arrUser = new PictureBox[3];   //圖片控制項陣列arrUser

        // 表單載入時執行
        private void Form1_Load(object sender, EventArgs e)
        {
            TmrRun.Interval = 50;  // 指定每50毫秒(即0.05秒)執行一次TmrRun_Tick事件
            //將電腦圖片控制項指定給arrPc
            arrPc[0] = PicPc1; arrPc[1] = PicPc2; arrPc[2] = PicPc3;
            //將玩家圖片控制項指定給arrUser
            arrUser[0] = PicUser1; arrUser[1] = PicUser2; arrUser[2] = PicUser3;
        }
        // 按 [開始] 鈕執行
        private void BtnStart_Click(object sender, EventArgs e)
        {
            pointPc = 0;    //設電腦得分為0
            for (int i = 0; i < arrPc.Length; i++)
            {
                int point = rnd.Next(1, 14);//產生1~13變數
                //顯示電腦的牌在arrPc對應的陣列元素
                arrPc[i].Image = ImgPoker.Images[point - 1];
                pointPc += point;   //累計電腦得分
            }
            TmrRun.Enabled = true;  //啟動TmrRun計時器
        }
        // 按 [停止] 鈕執行
        private void BtnStop_Click(object sender, EventArgs e)
        {
            TmrRun.Enabled = false; // 停止TmrRun計時器
            if (pointUser > pointPc)
            {
                LblMsg.Text = "恭喜你獲勝 !!";
            }
            else if (pointUser < pointPc)
            {
                LblMsg.Text = "抱歉電腦獲勝 !!";
            }
            else
            {
                LblMsg.Text = "雙方平手 !!";
            }
        }
        // 每50毫秒(即0.05秒)執行一次TmrRun_Tick事件
        private void TmrRun_Tick(object sender, EventArgs e)
        {
            pointUser = 0;    //設電腦得分為0
            for (int i = 0; i < arrUser.Length; i++)
            {
                int point = rnd.Next(1, 14);//產生1~13變數
                //顯示玩家的牌在arrUser對應的陣列元素
                arrUser[i].Image = ImgPoker.Images[point - 1];
                pointUser += point;   //累計玩家得分
            }
        }
    }
}
