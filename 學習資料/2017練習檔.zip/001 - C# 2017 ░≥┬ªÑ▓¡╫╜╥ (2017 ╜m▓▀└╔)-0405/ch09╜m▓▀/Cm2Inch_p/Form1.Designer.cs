﻿namespace Cm2Inch_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.LblInch = new System.Windows.Forms.Label();
            this.TxtCm = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LblInch
            // 
            this.LblInch.AutoSize = true;
            this.LblInch.Location = new System.Drawing.Point(36, 58);
            this.LblInch.Name = "LblInch";
            this.LblInch.Size = new System.Drawing.Size(33, 12);
            this.LblInch.TabIndex = 10;
            this.LblInch.Text = "label2";
            // 
            // TxtCm
            // 
            this.TxtCm.Location = new System.Drawing.Point(107, 14);
            this.TxtCm.Name = "TxtCm";
            this.TxtCm.Size = new System.Drawing.Size(100, 22);
            this.TxtCm.TabIndex = 9;
            this.TxtCm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtCm_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "輸入公分：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 91);
            this.Controls.Add(this.LblInch);
            this.Controls.Add(this.TxtCm);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblInch;
        private System.Windows.Forms.TextBox TxtCm;
        private System.Windows.Forms.Label label1;
    }
}

