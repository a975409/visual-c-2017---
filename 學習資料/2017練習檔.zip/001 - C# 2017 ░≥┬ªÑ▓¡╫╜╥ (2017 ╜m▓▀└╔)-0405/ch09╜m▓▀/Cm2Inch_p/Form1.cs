﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cm2Inch_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtCm.Text = "0";    //預設值為0
            TxtCm.Focus();      // TxtCm取得停駐焦點
            LblInch.Text = "請輸入公分後按計算鈕";
        }

        private void TxtCm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9')  //若不是0~9
            {
                switch (e.KeyChar)  //檢查輸入的字元
                {
                    case (char)Keys.Enter:  //Enter鍵
                        try
                        {
                            double inch = Convert.ToDouble(TxtCm.Text) / 2.54;
                            LblInch.Text = "等於 " + inch.ToString("F4") + " 英吋";
                            TxtCm.Focus();  // txtCm取得停駐焦點
                        }
                        catch (Exception)
                        {
                            LblInch.Text = "請輸入公分後按計算鈕";
                        }
                        break;
                    case '\b':  //退位鍵
                        break;
                    case '.':
                        if(TxtCm.Text.Length==0)    //如果字串長度為0，就不可輸入'.'
                        {
                            e.Handled = true;  //取消輸入的字元
                        }
                        else if (TxtCm.Text.IndexOf(".") > -1) //若txtCm已經有"."字元
                        {
                            e.Handled = true;  //取消輸入的字元
                        }
                        break;
                    default:
                        e.Handled = true;  //取消輸入的字元
                        break;
                }
            }
        }
    }
}
