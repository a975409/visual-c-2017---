﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MouseMove_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PicBtn.Image = Image.FromFile("button1.jpg");//載入button1.jpg
        }
        //滑鼠游標移入picBtn時
        private void PicBtn_MouseEnter(object sender, EventArgs e)
        {
            PicBtn.Image = Image.FromFile("button2.jpg");//載入button2.jpg
        }
        //滑鼠游標移出picBtn時
        private void PicBtn_MouseLeave(object sender, EventArgs e)
        {
            PicBtn.Image = Image.FromFile("button1.jpg");//載入button1.jpg
        }
        //在picBtn內按下滑鼠左鍵時
        private void PicBtn_MouseDown(object sender, MouseEventArgs e)
        {
            PicBtn.Image = Image.FromFile("button3.jpg");//載入button3.jpg
        }
        //在picBtn內放開滑鼠左鍵時
        private void PicBtn_MouseUp(object sender, MouseEventArgs e)
        {
            PicBtn.Image = Image.FromFile("button2.jpg");//載入button2.jpg
        }
    }
}
