﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vocation_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CboKind.DropDownStyle = ComboBoxStyle.DropDownList;  //設清單不能輸入
            CboKind.Items.Add("一般會員"); CboKind.Items.Add("高級會員");   //新增項目
            CboKind.Items.Add("尊爵會員"); CboKind.Items.Add("非會員");
            CboKind.SelectedIndex = 0;          //預設選取第一個項目
            McaDate.MinDate = DateTime.Today;   //設最早的選擇日期為今天
        }

        private void CboKind_SelectedIndexChanged(object sender, EventArgs e)
        {
            McaDate.Enabled = true; //設月曆可使用
            int[] days = { 5, 12, 21 }; //記錄各種會員的可住天數
            int sel = CboKind.SelectedIndex; //選擇的會員項目註標值
            if (sel == 3)
            {
                LblDays.Text = CboKind.Text + "恕不招待";
                McaDate.Enabled = false; //設月曆不可使用
                LblMsg.Text = string.Empty;
            }
            else
            {
                LblDays.Text = CboKind.Text + "最多可選" + days[sel].ToString() + "天入住";
                McaDate.MaxSelectionCount = days[sel]; //設最多選擇5天
            }
        }

        private void McaDate_DateChanged(object sender, DateRangeEventArgs e)
        {
            DateTime ds = McaDate.SelectionStart;   //ds紀錄入住日期
            DateTime de = McaDate.SelectionEnd;     //de紀錄退房日期
            TimeSpan ts = de - ds;  //ts為入住到退房日期的間隔時間
            int days = ts.Days + 1; //將時間間隔ts轉成天數
            //由McaDate.MaxSelectionCount可以取得可住天數
            LblMsg.Text="您選擇" + McaDate.SelectionStart.ToString("yyyy/MM/dd") + " 到 " + McaDate.SelectionEnd.ToString("yyyy/MM/dd") + " 入住，剩餘" + (McaDate.MaxSelectionCount-days) + "天";
        }
    }
}
