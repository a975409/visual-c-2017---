﻿namespace Vocation_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.McaDate = new System.Windows.Forms.MonthCalendar();
            this.LblDays = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.CboKind = new System.Windows.Forms.ComboBox();
            this.LblMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // McaDate
            // 
            this.McaDate.Location = new System.Drawing.Point(30, 65);
            this.McaDate.Name = "McaDate";
            this.McaDate.TabIndex = 22;
            this.McaDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.McaDate_DateChanged);
            // 
            // LblDays
            // 
            this.LblDays.AutoSize = true;
            this.LblDays.Location = new System.Drawing.Point(28, 44);
            this.LblDays.Name = "LblDays";
            this.LblDays.Size = new System.Drawing.Size(37, 12);
            this.LblDays.TabIndex = 21;
            this.LblDays.Text = "Label2";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(24, 9);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(101, 12);
            this.Label1.TabIndex = 20;
            this.Label1.Text = "請選擇會員資格：";
            // 
            // CboKind
            // 
            this.CboKind.FormattingEnabled = true;
            this.CboKind.Location = new System.Drawing.Point(131, 6);
            this.CboKind.Name = "CboKind";
            this.CboKind.Size = new System.Drawing.Size(121, 20);
            this.CboKind.TabIndex = 19;
            this.CboKind.SelectedIndexChanged += new System.EventHandler(this.CboKind_SelectedIndexChanged);
            // 
            // LblMsg
            // 
            this.LblMsg.AutoSize = true;
            this.LblMsg.Location = new System.Drawing.Point(18, 240);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(33, 12);
            this.LblMsg.TabIndex = 23;
            this.LblMsg.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.LblMsg);
            this.Controls.Add(this.McaDate);
            this.Controls.Add(this.LblDays);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.CboKind);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.MonthCalendar McaDate;
        internal System.Windows.Forms.Label LblDays;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox CboKind;
        private System.Windows.Forms.Label LblMsg;
    }
}

