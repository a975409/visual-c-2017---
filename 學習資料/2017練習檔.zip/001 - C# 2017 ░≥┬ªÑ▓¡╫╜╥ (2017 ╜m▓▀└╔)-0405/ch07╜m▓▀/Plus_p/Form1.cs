﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plus_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] pic = new string[] { "花.jpg", "船.jpg", "湖.jpg", "纜車.jpg" };
        private void Form1_Load(object sender, EventArgs e)
        {
            NudPic.Minimum = 1; //NudPic最小值為1
            NudPic.Maximum = 4; //NudPic最大值為4
            NudPic.ReadOnly = true;
            PicShow.SizeMode = PictureBoxSizeMode.StretchImage;
            //NudPic.Value的資料型別為Decimal所以用(int)轉型為整數，作為註標值來取得陣列值
            PicShow.Image = Image.FromFile(pic[(int)NudPic.Value - 1]);//載入圖檔
            PicShow.Height = 90; PicShow.Width = 90;//設定圖片高度和寬度
            VsbHeight.Maximum = 180;    //設定VsbHeight的最大值 = 180
            HsbWidth.Maximum = 180;     //設定HsbWidth的最大值 = 180
            VsbHeight.Value = PicShow.Height;   //VsbHeight的Value值=圖片高度
            HsbWidth.Value = PicShow.Width;     //HsbWidth的Value值=圖片寬度
            LblH.Text = "高度=90"; LblW.Text = "寬度=90";
            VsbHeight.LargeChange = 1;    //設定VsbHeight的快動值 = 1
            HsbWidth.LargeChange = 1;     //設定HsbWidth的快動值 = 1
        }
        // 捲動垂直捲軸時執行
        private void VsbHeight_Scroll(object sender, ScrollEventArgs e)
        {
            PicShow.Height = VsbHeight.Value;   //設圖片高度=VsbHeight的Value值
            LblH.Text = "高度=" + VsbHeight.Value.ToString();
        }
        // 捲動水平捲軸時執行
        private void HsbWidth_Scroll(object sender, ScrollEventArgs e)
        {
            PicShow.Width = HsbWidth.Value; //設圖片寬度=HsbWidth的Value值
            LblW.Text = "寬度=" + HsbWidth.Value.ToString();
        }
        // 數字鈕Value改變時執行圖檔切換
        private void NudPic_ValueChanged(object sender, EventArgs e)
        {
            PicShow.Image = Image.FromFile(pic[(int)NudPic.Value - 1]);//載入圖檔
        }
    }
}
