﻿namespace Plus_p
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.NudPic = new System.Windows.Forms.NumericUpDown();
            this.LblW = new System.Windows.Forms.Label();
            this.LblH = new System.Windows.Forms.Label();
            this.PicShow = new System.Windows.Forms.PictureBox();
            this.VsbHeight = new System.Windows.Forms.VScrollBar();
            this.HsbWidth = new System.Windows.Forms.HScrollBar();
            ((System.ComponentModel.ISupportInitialize)(this.NudPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicShow)).BeginInit();
            this.SuspendLayout();
            // 
            // NudPic
            // 
            this.NudPic.Location = new System.Drawing.Point(217, 197);
            this.NudPic.Name = "NudPic";
            this.NudPic.Size = new System.Drawing.Size(55, 22);
            this.NudPic.TabIndex = 22;
            this.NudPic.ValueChanged += new System.EventHandler(this.NudPic_ValueChanged);
            // 
            // LblW
            // 
            this.LblW.AutoSize = true;
            this.LblW.Location = new System.Drawing.Point(217, 240);
            this.LblW.Name = "LblW";
            this.LblW.Size = new System.Drawing.Size(33, 12);
            this.LblW.TabIndex = 21;
            this.LblW.Text = "label2";
            // 
            // LblH
            // 
            this.LblH.AutoSize = true;
            this.LblH.Location = new System.Drawing.Point(217, 222);
            this.LblH.Name = "LblH";
            this.LblH.Size = new System.Drawing.Size(33, 12);
            this.LblH.TabIndex = 20;
            this.LblH.Text = "label1";
            // 
            // PicShow
            // 
            this.PicShow.Location = new System.Drawing.Point(30, 26);
            this.PicShow.Name = "PicShow";
            this.PicShow.Size = new System.Drawing.Size(180, 180);
            this.PicShow.TabIndex = 19;
            this.PicShow.TabStop = false;
            // 
            // VsbHeight
            // 
            this.VsbHeight.Location = new System.Drawing.Point(238, 9);
            this.VsbHeight.Name = "VsbHeight";
            this.VsbHeight.Size = new System.Drawing.Size(17, 180);
            this.VsbHeight.TabIndex = 18;
            this.VsbHeight.Scroll += new System.Windows.Forms.ScrollEventHandler(this.VsbHeight_Scroll);
            // 
            // HsbWidth
            // 
            this.HsbWidth.Location = new System.Drawing.Point(13, 226);
            this.HsbWidth.Name = "HsbWidth";
            this.HsbWidth.Size = new System.Drawing.Size(180, 17);
            this.HsbWidth.TabIndex = 17;
            this.HsbWidth.Scroll += new System.Windows.Forms.ScrollEventHandler(this.HsbWidth_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.NudPic);
            this.Controls.Add(this.LblW);
            this.Controls.Add(this.LblH);
            this.Controls.Add(this.PicShow);
            this.Controls.Add(this.VsbHeight);
            this.Controls.Add(this.HsbWidth);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NudPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicShow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown NudPic;
        private System.Windows.Forms.Label LblW;
        private System.Windows.Forms.Label LblH;
        private System.Windows.Forms.PictureBox PicShow;
        private System.Windows.Forms.VScrollBar VsbHeight;
        private System.Windows.Forms.HScrollBar HsbWidth;
    }
}

