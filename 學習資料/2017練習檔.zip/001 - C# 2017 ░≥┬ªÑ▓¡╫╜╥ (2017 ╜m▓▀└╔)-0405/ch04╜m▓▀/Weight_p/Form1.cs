﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Weight_p
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtHeight.Text = "160";  //預設身高為160公分
            RdbMan.Checked = true;  //預設為男性
        }
        //RdbMan的選取狀態改變時會觸動CheckedChanged事件
        //因為只有兩個選項鈕，若選取RdbWoman(女)時,除RdbWoman的選取狀態改變外
        //RdbMan的Checked也會由true變false，所以只要使用一個事件程序即可
        private void RdbMan_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                int height = Convert.ToInt32(TxtHeight.Text);  //取得身高
                double weight;  //紀錄標準體重
                if (RdbMan.Checked == true)  //若RdbMan的Checked屬性值=true
                    weight = (height - 80) * 0.7;  //計算男性標準體重
                else
                    weight = (height - 70) * 0.6;  //計算女性標準體重
                LblMsg.Text = "標準體重：" + weight.ToString("f1") + "公斤";
            }
            catch
            {
                MessageBox.Show("身高請輸入數值！", "注意");
            }
        }

        private void TxtHeight_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int height = Convert.ToInt32(TxtHeight.Text);  //取得身高
                double weight;  //紀錄標準體重
                if (RdbMan.Checked == true)  //若RdbMan的Checked屬性值=true
                    weight = (height - 80) * 0.7;  //計算男性標準體重
                else
                    weight = (height - 70) * 0.6;  //計算女性標準體重
                LblMsg.Text = "標準體重：" + weight.ToString("f1") + "公斤";
            }
            catch
            {
                MessageBox.Show("身高請輸入數值！", "注意");
            }
        }
    }
}
