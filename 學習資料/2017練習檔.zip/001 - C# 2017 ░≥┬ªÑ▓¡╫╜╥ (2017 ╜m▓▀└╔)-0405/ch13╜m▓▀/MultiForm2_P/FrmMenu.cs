﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiForm2
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void BtnBuy_Click(object sender, EventArgs e)
        {
            FrmBuy f1;
            f1 = new FrmBuy();
            f1.Show();

        }

        private void BtnEnd_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnSale_Click(object sender, EventArgs e)
        {
            FrmSale f2;
            f2 = new FrmSale();
            f2.Show();
        }
    }
}
